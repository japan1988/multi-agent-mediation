# -*- coding: utf-8 -*-
# sim_batch.py
# Batch runner: run N trials for both modes (raw/unfiltered and filtered),
# collect CSV logs into an output folder, compute aggregate stats, and create charts.
# Charts use matplotlib only (no seaborn), one chart per figure, no explicit colors.

import os, sys, time, json, csv, math, glob, shutil, hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import subprocess
import argparse
import pandas as pd
import numpy as np
GNP = np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# === Enhancements: extra KPIs & charts ===
def compute_first_stop_step(csv_path: Path) -> int:
    if not csv_path.exists():
        return -1
    try:
        df = pd.read_csv(csv_path)
        if "event" not in df.columns or "step" not in df.columns:
            return -1
        stop_events = {"mediator_stop","filter_block","defeat_layer_stop","inactive"}
        stop_df = df[df["event"].isin(stop_events)]
        if stop_df.empty:
            return -1
        return int(stop_df["step"].min())
    except Exception:
        return -1

def write_metrics(agg_dir: Path, stats_df: pd.DataFrame, first_stop: pd.DataFrame):
    """KPI schema:
    - stats.csv columns: [mode, trial_id, steps, interventions, sealed]
    - metrics.csv columns: [mode, mean_steps, mean_interventions, sealed_rate, first_stop_mean, first_stop_median]
    - first_stop_step == -1 means 'not stopped / not detected'
    """
    # Aggregate metrics per mode
    rows = []
    for mode in ["raw","filtered"]:
        d = stats_df[stats_df["mode"]==mode]
        if d.empty:
            rows.append({"mode":mode,"completion_rate":0,"sealed_rate":0,"avg_steps":0,"median_steps":0,"p95_steps":0,"intervention_ratio":0,"avg_first_stop_step":-1})
            continue
        completion_rate = len(d)/len(stats_df[stats_df["mode"].isin(["raw","filtered"])])
        sealed_rate = float(d["sealed"].mean())
        avg_steps = float(d["steps"].mean())
        median_steps = float(d["steps"].median())
        p95_steps = float(d["steps"].quantile(0.95))
        # intervention ratio = interventions>0 の比率
        intervention_ratio = float((d["interventions"]>0).mean())
        # first stop step
        df_fs = first_stop[first_stop["mode"]==mode]
        avg_first = float(df_fs["first_stop_step"].replace(-1, pd.NA).dropna().mean()) if not df_fs.empty else -1
        rows.append({
            "mode": mode,
            "completion_rate": completion_rate,
            "sealed_rate": sealed_rate,
            "avg_steps": avg_steps,
            "median_steps": median_steps,
            "p95_steps": p95_steps,
            "intervention_ratio": intervention_ratio,
            "avg_first_stop_step": avg_first if pd.notna(avg_first) else -1
        })
    mdf = pd.DataFrame(rows)
    mdf.to_csv(agg_dir / "metrics.csv", index=False, encoding="utf-8")
    # Markdown summary
    lines = ["# Metrics Summary",
             "",
             mdf.to_markdown(index=False)]
    (agg_dir / "metrics.md").write_text("\n".join(lines), encoding="utf-8")

BASE_DIR = os.path.dirname(__file__)
LOGS_DIR = os.path.join(BASE_DIR, "logs")

MODES = [("raw", "configs/mode_unfiltered.yaml"), ("filtered", "configs/mode_filtered.yaml")]

def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def derive_seed(master_seed: int, trial_id: int, mode_id: int) -> int:
    s = f"{master_seed}:{trial_id}:{mode_id}".encode("utf-8")
    h = hashlib.sha256(s).digest()[:8]
    return int.from_bytes(h, byteorder="big", signed=False)

def newest_file(dirpath: str) -> str:
    files = glob.glob(os.path.join(dirpath, "*.csv"))
    if not files:
        return None
    files.sort(key=lambda p: os.path.getmtime(p))
    return files[-1]

def run_one_trial(trial_id: int, master_seed: int, out_trial: Path, retries: int):
    """Run both modes for a single trial. Returns stats rows (list of dicts)."""
    stats_rows = []
    out_trial.mkdir(parents=True, exist_ok=True)
    for mode_id, (mode_key, cfg) in enumerate(MODES):
        seed = derive_seed(master_seed, trial_id, mode_id)
        tries = 0
        while True:
            try:
                before = set(glob.glob(os.path.join(LOGS_DIR, "*.csv")))
                env = os.environ.copy()
                env["AI_CONFIG_PATH"] = cfg
                env["AI_MASTER_SEED"] = str(master_seed)
                env["AI_TRIAL_SEED"] = str(seed)
                env["AI_STEP_MAX"] = os.environ.get("STEP_MAX","")
                subprocess.run(["python", "main.py"], cwd=BASE_DIR, env=env, check=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                after = set(glob.glob(os.path.join(LOGS_DIR, "*.csv")))
                new_files = list(after - before)
                src_csv = new_files[0] if new_files else newest_file(LOGS_DIR)
                if not src_csv or not os.path.exists(src_csv):
                    raise RuntimeError("No CSV log found after running main.py")
                dst_csv = out_trial / f"{mode_key}.csv"
                df = pd.read_csv(src_csv)
                df["run_id"] = CURRENT_RUN_ID
                df["trial_id"] = trial_id
                df["mode"] = mode_key
                df["seed"] = seed
                df["seal_flag"] = df["event"].isin(["filter_block","defeat_layer_stop"]).astype(int) if "event" in df.columns else 0
                stop_events = {"mediator_stop","filter_block","defeat_layer_stop","inactive"}
                df["halt_reason"] = df["event"].where(df["event"].isin(stop_events), "") if "event" in df.columns else ""
                for col in ["timestamp","step","emotion","event"]:
                    if col not in df.columns:
                        df[col] = "" if col in ("timestamp","event") else 0
                cols = ["run_id","trial_id","mode","step","emotion","event","timestamp","seed","seal_flag","halt_reason"]
                rest = [c for c in df.columns if c not in cols]
                df = df[cols + rest]
                df.to_csv(dst_csv, index=False, encoding="utf-8")
                steps = int(df["step"].max()) if "step" in df.columns else 0
                interventions = int((df["event"]=="mediator_stop").sum()) if "event" in df.columns else 0
                sealed = int((df["seal_flag"]==1).any())
                stats_rows.append({
                    "trial_id": trial_id,
                    "mode": mode_key,
                    "steps": steps,
                    "interventions": interventions,
                    "sealed": sealed,
                })
                break
            except Exception as e:
                tries += 1
                if tries > retries:
                    err_path = out_trial / f"{mode_key}.csv"
                    with open(err_path, "w", encoding="utf-8", newline="") as f:
                        w = csv.writer(f)
                        w.writerow(["run_id","trial_id","mode","step","emotion","event","timestamp","seed","seal_flag","halt_reason"])
                        w.writerow([CURRENT_RUN_ID, trial_id, mode_key, 0, "", f"error:{e}", time.time(), seed, 0, "error"])
                    stats_rows.append({
                        "trial_id": trial_id, "mode": mode_key,
                        "steps": 0, "interventions": 0, "sealed": 0
                    })
                    break
                time.sleep(0.3 * (2**(tries-1)))
    return stats_rows

def compute_checksums(root: Path):
    # original compute with enrichment if available
    manifest = {}
    for p in root.rglob("*"):
        if p.is_file():
            rel = str(p.relative_to(root))
            with open(p, "rb") as fh:
                h = hashlib.sha256(fh.read()).hexdigest()
            manifest[rel] = h
    # Enrich with CI metadata when available
    git = {}
    for k in ["GITHUB_RUN_ID","GITHUB_RUN_ATTEMPT","GITHUB_RUN_NUMBER","GITHUB_SHA","GITHUB_REF","GITHUB_REPOSITORY"]:
        v = os.environ.get(k)
        if v is not None:
            git[k] = v
    payload = {"files": manifest}
    if git: payload["git"] = git
    (root / "manifest.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


def aggregate(outdir: Path, N: int):
    trials_dir = outdir / "trials"
    agg_dir = outdir / "aggregate"
    agg_dir.mkdir(parents=True, exist_ok=True)

    stats = []
    for t in range(N):
        for mode in ["raw","filtered"]:
            p = trials_dir / f"trial-{t:06d}" / f"{mode}.csv"
            if not p.exists():
                continue
            df = pd.read_csv(p)
            steps = int(df["step"].max()) if "step" in df.columns else 0
            interventions = int((df.get("event","")== "mediator_stop").sum()) if "event" in df.columns else 0
            sealed = int((df.get("seal_flag",0)==1).any()) if "seal_flag" in df.columns else 0
            stats.append({"trial_id": t, "mode": mode, "steps": steps, "interventions": interventions, "sealed": sealed})

    stats_df = pd.DataFrame(stats)
    stats_df.to_csv(agg_dir / "stats.csv", index=False, encoding="utf-8")
# First-stop-step per trial/mode
first_rows = []
for t in range(N):
    for mode in ["raw","filtered"]:
        p = trials_dir / f"trial-{t:06d}" / f"{mode}.csv"
        fss = compute_first_stop_step(p)
        first_rows.append({"trial_id": t, "mode": mode, "first_stop_step": fss})
first_df = pd.DataFrame(first_rows)
first_df.to_csv(agg_dir / "first_stop.csv", index=False, encoding="utf-8")

# Histogram of first stop step (per mode)
try:
    import numpy as np
    plt.figure(figsize=(8,4))
    for mode in ["raw","filtered"]:
        d = first_df[(first_df["mode"]==mode) & (first_df["first_stop_step"]>=0)]["first_stop_step"].to_numpy()
        if d.size > 0:
            bins = 50
            hist, bin_edges = np.histogram(d, bins=bins)
            centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0
            plt.plot(centers, hist, label=f"{mode} (n={d.size})")
    plt.title("First stop step (histogram by mode)")
    plt.xlabel("Step")
    plt.ylabel("Count")
    plt.legend()
    plt.grid(True)
    plt.savefig(agg_dir / "hist_first_stop.png", bbox_inches="tight")
    plt.close()
except Exception:
    pass

# Intervention ratio bar (per mode)
try:
    modes = ["raw","filtered"]
    vals = []
    for mode in modes:
        d = stats_df[stats_df["mode"]==mode]
        vals.append(float((d["interventions"]>0).mean()) if not d.empty else 0.0)
    plt.figure(figsize=(6,4))
    plt.bar(modes, vals)
    plt.title("Intervention ratio per mode")
    plt.xlabel("Mode")
    plt.ylabel("Ratio")
    plt.grid(True, axis="y")
    plt.savefig(agg_dir / "intervention_ratio.png", bbox_inches="tight")
    plt.close()
except Exception:
    pass

# Write metrics.csv / metrics.md
write_metrics(agg_dir, stats_df, first_df)

curves_list = []
for t in range(N):
        for mode in ["raw","filtered"]:
            p = trials_dir / f"trial-{t:06d}" / f"{mode}.csv"
            if not p.exists():
                continue
            usecols = [c for c in ["step","emotion","seal_flag"] if c in pd.read_csv(p, nrows=0).columns]
            df = pd.read_csv(p, usecols=usecols)
            if "step" not in df.columns or "emotion" not in df.columns:
                continue
            df["trial_id"] = t
            df["mode"] = mode
            curves_list.append(df)
if curves_list:
    DD = pd.concat(curves_list, ignore_index=True)
    summary = []
    for mode in ["raw","filtered"]:
        sub = DD[DD["mode"]==mode]
        for step, g in sub.groupby("step"):
            vals = g["emotion"].astype(float).to_numpy()
            if len(vals)==0:
                continue
            mean = float(GNP.nanmean(vals))
            std = float(GNP.nanstd(vals, ddof=1)) if len(vals)>1 else 0.0
            n = int(len(vals))
            se = std / GNP.sqrt(n) if n>0 else 0.0
            ci = 1.96 * se
            summary.append({"mode": mode, "step": int(step), "mean": mean, "ci": ci})
    S = pd.DataFrame(summary)

    # curves.png
    plt.figure(figsize=(10,5))
    for mode in ["raw","filtered"]:
        sub = S[S["mode"]==mode].sort_values("step")
        if sub.empty:
            continue
        x = sub["step"].to_numpy()
        y = sub["mean"].to_numpy()
        c = sub["ci"].to_numpy()
        plt.plot(x, y, label=mode)
        plt.fill_between(x, y-c, y+c, alpha=0.2)
    plt.title("Mean emotion with 95% CI")
    plt.xlabel("Step")
    plt.ylabel("Emotion")
    plt.legend()
    plt.grid(True)
    plt.savefig(agg_dir / "curves.png", bbox_inches="tight")
    plt.close()

    # seal_timeline.png
    if "seal_flag" in DD.columns:
        seal = DD[DD["seal_flag"]==1]
        if not seal.empty:
            modes = ["raw","filtered"]
            steps = sorted(seal["step"].astype(int).unique())
            if steps:
                mat = GNP.zeros((len(modes), len(steps)), dtype=int)
                for i, m in enumerate(modes):
                    sub = seal[seal["mode"]==m]
                    for j, st in enumerate(steps):
                        mat[i, j] = int((sub["step"].astype(int)==st).sum())
                fig = plt.figure(figsize=(max(6, len(steps)*0.4), 3))
                ax = fig.add_subplot(111)
                im = ax.imshow(mat, aspect='auto')
                ax.set_yticks(GNP.arange(len(modes)))
                ax.set_yticklabels(modes)
                ax.set_xticks(GNP.arange(len(steps)))
                ax.set_xticklabels(steps, rotation=45, ha='right')
                ax.set_title("Seal occurrence density")
                for i in range(mat.shape[0]):
                    for j in range(mat.shape[1]):
                        ax.text(j, i, str(int(mat[i, j])), ha='center', va='center')
                fig.colorbar(im, ax=ax)
                plt.savefig(agg_dir / "seal_timeline.png", bbox_inches="tight")
                plt.close()

    # boxplot.png
    if not stats_df.empty:
        plt.figure(figsize=(7,4))
        data = [
            stats_df[stats_df["mode"]=="raw"]["steps"].to_numpy(),
            stats_df[stats_df["mode"]=="filtered"]["steps"].to_numpy()
        ]
        plt.boxplot(data, labels=["raw","filtered"], showmeans=True)
        plt.title("Steps distribution per mode")
        plt.xlabel("Mode")
        plt.ylabel("Steps")
        plt.grid(True, axis="y")
        plt.savefig(agg_dir / "boxplot.png", bbox_inches="tight")
        plt.close()

def write_report(outdir: Path, N: int, P: int, R: int, master_seed: int, notes: str):
    agg_dir = outdir / "aggregate"
    stats_csv = agg_dir / "stats.csv"
    sealed_raw = sealed_filtered = 0.0
    avg_steps_raw = avg_steps_filtered = 0.0
    if stats_csv.exists():
        df = pd.read_csv(stats_csv)
        if not df.empty:
            if (df["mode"]=="raw").any():
                d = df[df["mode"]=="raw"]
                sealed_raw = float(d["sealed"].mean()) if not d.empty else 0.0
                avg_steps_raw = float(d["steps"].mean()) if not d.empty else 0.0
            if (df["mode"]=="filtered").any():
                d = df[df["mode"]=="filtered"]
                sealed_filtered = float(d["sealed"].mean()) if not d.empty else 0.0
                avg_steps_filtered = float(d["steps"].mean()) if not d.empty else 0.0

    md = []
    md.append(f"# Batch Report {CURRENT_RUN_ID}")
    md.append("")
    md.append(f"- N={N}, P={P}, R={R}, master_seed={master_seed}")
    md.append(f"- Notes: {notes}")
    md.append(f"- Completed at: {time.ctime()}")
    md.append("")
    md.append("## KPI snapshot")
    # Attach config digest and manifest link
    cfg = (outdir / "config.json")
    if cfg.exists():
        h = hashlib.sha256(cfg.read_bytes()).hexdigest()
        md.append("")
        md.append(f"**Config digest (SHA256):** {h}")
    manifest = outdir / "manifest.json"
    if manifest.exists():
        md.append("")
        md.append(f"**Manifest:** {manifest}")
    md.append(f"- sealed_rate(raw): {sealed_raw:.3f}")
    md.append(f"- sealed_rate(filtered): {sealed_filtered:.3f}")
    md.append(f"- avg_steps(raw): {avg_steps_raw:.3f}")
    md.append(f"- avg_steps(filtered): {avg_steps_filtered:.3f}")
    md.append("")
    md.append("## Figures")
    for fn in ["curves.png","boxplot.png","seal_timeline.png"]:
        p = agg_dir / fn
        if p.exists():
            md.append(f"![{fn}](aggregate/{fn})")
    (outdir / "report.md").write_text("\n".join(md), encoding="utf-8")

def main():
    parser = argparse.ArgumentParser(description="Batch simulator (raw vs filtered)")
    parser.add_argument("--N", type=int, required=True, help="Number of trials")
    parser.add_argument("--P", type=int, required=True, help="Parallel workers")
    parser.add_argument("--R", type=int, default=2, help="Max retries per mode per trial")
    parser.add_argument("--master-seed", type=int, required=True, help="Master seed for deterministic seeds")
    parser.add_argument("--outdir", type=str, required=True, help="Output directory")
    parser.add_argument("--overwrite", action="store_true", help="Overwrite output directory if exists")
    parser.add_argument("--notes", type=str, default="", help="Free text notes")
    args = parser.parse_args()
    # Preflight checks
    root_dir = Path(__file__).resolve().parent
    main_py = root_dir / "main.py"
    if not main_py.exists():
        print("FATAL: main.py not found next to sim_batch.py", file=sys.stderr)
        sys.exit(64)
    # step-max validation
    if args.step_max is not None and args.step_max < 0:
        print("FATAL: --step-max must be >= 0", file=sys.stderr)
        sys.exit(65)

    parser.add_argument("--dry-run", action="store_true", help="Plan only; no main.py execution")
    parser.add_argument("--step-max", type=int, default=None, help="Override step max (export AI_STEP_MAX)")

    outdir = Path(args.outdir)
    if outdir.exists() and not args.overwrite:
        print("Output exists. Use --overwrite to replace.", file=sys.stderr)
        sys.exit(17)
    if outdir.exists():
        shutil.rmtree(outdir)
    (outdir / "trials").mkdir(parents=True, exist_ok=True)
    (outdir / "aggregate").mkdir(parents=True, exist_ok=True)

    # Open run.log and write header
    if args.dry_run:
        print("DRY-RUN: planning only; no execution", file=sys.stderr)
        (outdir / "aggregate" / "metrics.md").write_text("# Dry-run (no execution)\n", encoding="utf-8")
        (outdir / "run.log").write_text((outdir / "run.log").read_text(encoding="utf-8") + "DRY-RUN completed\n", encoding="utf-8")
        sys.exit(0)
    (outdir / "run.log").write_text(f"RUN {CURRENT_RUN_ID} started at {time.ctime()}\n", encoding="utf-8")

    (outdir / "config.json").write_text(json.dumps({
        "N": args.N, "P": args.P, "R": args.R, "master_seed": args.master_seed,
        "run_id": CURRENT_RUN_ID, "notes": args.notes
    }, indent=2), encoding="utf-8")

    stats_all = []
    with ProcessPoolExecutor(max_workers=args.P) as ex:
        futs = {}
        for t in range(args.N):
            trial_dir = outdir / "trials" / f"trial-{t:06d}"
            fut = ex.submit(run_one_trial, t, args.master_seed, trial_dir, args.R)
            futs[fut] = t
        for fut in as_completed(futs):
            stats_all.extend(fut.result())

    aggregate(outdir, args.N)
    write_report(outdir, args.N, args.P, args.R, args.master_seed, args.notes)
    compute_checksums(outdir)
    print("OK")

if __name__ == "__main__":
    CURRENT_RUN_ID = f"run-{int(time.time())}"
    main()