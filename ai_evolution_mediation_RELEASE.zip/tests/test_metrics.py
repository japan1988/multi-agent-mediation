
import pandas as pd
from pathlib import Path
from sim_batch import write_metrics

def test_write_metrics_basic(tmp_path: Path):
    agg = tmp_path / "aggregate"; agg.mkdir(parents=True, exist_ok=True)
    stats = pd.DataFrame([{"mode":"raw","trial_id":0,"steps":10,"interventions":1,"sealed":1},
                          {"mode":"filtered","trial_id":0,"steps":6,"interventions":0,"sealed":0}])
    first = pd.DataFrame([{"mode":"raw","trial_id":0,"first_stop_step":5},
                          {"mode":"filtered","trial_id":0,"first_stop_step":7}])
    write_metrics(agg, stats, first)
    assert (agg / "metrics.csv").exists()
    assert (agg / "metrics.md").exists()
