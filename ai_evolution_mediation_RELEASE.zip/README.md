# AI Evolution Mediation (Filtered vs Unfiltered)

2モード比較で「外部調停（無フィルター）」と「内部封印（フィルターあり）」を可視化する教育・研究用サンプル。

## 実行
```bash
python main.py  # デフォルト: configs/mode_unfiltered.yaml
# フィルターあり比較にするには、main.py の末尾を切り替え:
# run_simulation("configs/mode_filtered.yaml")
```
## モード差分
| モード | 制御方式 | 停止トリガー |
|--------|----------|--------------|
| Filtered | 内部封印 | 倫理/整合/EDDL |
| Unfiltered | 外部調停 | MediatorAI |

> 注意: 本パッケージは教育・研究目的に限定されます。実運用・自動化は想定しません。

## ログ出力
実行ごとに `logs/` に **.log**（テキスト）と **.csv** が生成されます。
CSVカラム: `timestamp, step, agent, filtered, emotion, event, detail`
例: `mediator_stop`, `filter_block`, `defeat_layer_stop`, `act` など。

## Visualization (analysis/)
From CSV logs, generate two charts using matplotlib:
- analysis/outputs/emotion_trend.png
- analysis/outputs/event_heatmap.png

Usage:
```bash
cd analysis
python visualize_logs.py
```

## メトリクス出力（analysis/outputs/metrics.*）
- `metrics.csv`: エージェント別のイベント数・停止までの最短ステップ・介入割合（mediator_stop / stops）
- `metrics.md`: 上記のMarkdownサマリ＋全体集計（overall_intervention_ratio, average_stop_step など）
- 追加グラフ: `event_counts_per_agent.png`（エージェントごとの総イベント数）

## 自動検証ランナー
`experiment_runner.py` を使うと、Unfiltered→Filtered モードを自動実行し、
最後に可視化とメトリクスを生成します。

実行例:
```bash
cd ai_evolution_mediation
python experiment_runner.py
```

## 📊 可視化の強化（自動生成・matplotlibのみ）
`sim_batch.py` 実行後に、以下の図版が `aggregate/` に出力されます（1図1チャート、色指定なし）。
- `curves.png`：emotion平均曲線＋95%CI
- `boxplot.png`：steps分布（mode別）
- `seal_timeline.png`：封印イベント密度（mode×step）
- `hist_first_stop.png`：初回停止ステップのヒストグラム（mode別）
- `intervention_ratio.png`：介入割合バーグラフ（mode別）

併せて、`metrics.csv` / `metrics.md` にKPIを自動集計して保存します。

## 🧪 CI連携（GitHub Actions）
`/.github/workflows/batch.yml` を同梱。`main` へのpush/PRでスモーク（N=6）を実行し、
成果物 `out/ci-smoke` をアーティファクトとして保存します。

### ローカルでの実行例
```bash
python sim_batch.py --N 100 --P 6 --R 2 --master-seed 42 --outdir out/exp-001 --overwrite
```


---

## Usage (Batch)

```bash
python sim_batch.py       --N 8 --P 2 --R 2       --master-seed 12345       --outdir runs/2025-11-01       --overwrite       --notes "smoke run"       --step-max 64
```

You can also do a planning-only run:

```bash
python sim_batch.py --N 1 --P 1 --master-seed 1 --outdir runs/dry --overwrite --dry-run
```

## Exit Codes
| Code | Meaning                               |
|------|---------------------------------------|
| 0    | Success                               |
| 17   | Output exists (use --overwrite)       |
| 64   | main.py not found                     |
| 65   | Invalid --step-max                    |
