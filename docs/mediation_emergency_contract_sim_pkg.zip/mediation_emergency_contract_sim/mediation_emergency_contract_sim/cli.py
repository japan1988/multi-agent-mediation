"""Console script entry."""

from .simulator import run_cli

def main() -> None:
    raise SystemExit(run_cli())

