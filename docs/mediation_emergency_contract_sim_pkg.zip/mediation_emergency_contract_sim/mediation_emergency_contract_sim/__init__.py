"""Emergency contract mediation simulator package (v5.1.2 emotion4)."""
__all__ = ["run_cli"]
from .simulator import run_cli
