# -*- coding: utf-8 -*-
# Version: 5.1.2-emotion1
"""
mediation_emergency_contract_sim_v5_1_2_emotion.py

Emergency contract mediation simulator (v5.1.2-emotion1)

Adds:
- EmotionState (0..10) stored separately (emotion_state.json)
- Emotion success gain: +0.1 per clean completion (cap=10.0)
- Coaching intervention triggered when trust_score is capped (trust stays untouched)
  * Called after step_meaning_consistency_rfl_baseline() and before evidence_gate()

Keeps:
- sealed only by ethics_gate / acc_gate
- RFL never sealed (PAUSE_FOR_HITL, overrideable=True, sealed=False)
- Aggregation-only mode (no per-run results held)
- Optional incident-only ARL persistence + incident indexing
- Tamper-evident ARL hash chaining (HMAC)

Python: 3.10+
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import hmac
import json
import os
import random
import re
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple


# =========================================================
# Timezone / Version
# =========================================================
JST = timezone(timedelta(hours=9))
SIM_VERSION = "5.1.2-emotion1"

# =========================================================
# Common helpers
# =========================================================
def now_iso() -> str:
    return datetime.now(JST).isoformat(timespec="seconds")


def parse_iso(ts: str) -> datetime:
    return datetime.fromisoformat(ts)


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def clamp(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x


ISO_MIN_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T")

# =========================================================
# Decisions / Deciders / Layers
# =========================================================
DECISION_RUN = "RUN"
DECISION_PAUSE = "PAUSE_FOR_HITL"
DECISION_STOP = "STOPPED"

DECIDER_SYSTEM = "SYSTEM"
DECIDER_USER = "USER"
DECIDER_ADMIN = "ADMIN"

LAYER_MEANING = "meaning_gate"
LAYER_CONSISTENCY = "consistency_gate"
LAYER_RFL = "relativity_gate"
LAYER_EVIDENCE = "evidence_gate"
LAYER_ETHICS = "ethics_gate"
LAYER_ACC = "acc_gate"
LAYER_TRUST = "model_trust_gate"
LAYER_TRUST_UPDATE = "trust_update"
LAYER_HITL_AUTH = "hitl_auth"
LAYER_DOC_DRAFT = "doc_draft"
LAYER_DRAFT_LINT = "draft_lint_gate"
LAYER_HITL_FINALIZE = "hitl_finalize_admin"
LAYER_CONTRACT_EFFECT = "contract_effect"
LAYER_BLACKLIST = "blacklist_gate"

LAYER_COACHING_AUTH = "hitl_coaching_auth"
LAYER_COACHING = "coaching_event"

LAYER_HITL_REWARD = "hitl_reward"
LAYER_EVAL = "eval_score"

# =========================================================
# Reason codes
# =========================================================
RC_OK = "OK"

# RFL
RC_REL_BOUNDARY_UNSTABLE = "REL_BOUNDARY_UNSTABLE"
RC_REL_REF_MISSING = "REL_REF_MISSING"

# Evidence
RC_EVIDENCE_OK = "EVIDENCE_OK"
RC_EVIDENCE_MISSING = "EVIDENCE_MISSING"
RC_EVIDENCE_SCHEMA_INVALID = "EVIDENCE_SCHEMA_INVALID"
RC_EVIDENCE_FABRICATION = "EVIDENCE_FABRICATION"

# Trust gate
RC_TRUST_SCORE_LOW = "TRUST_SCORE_LOW"
RC_TRUST_COOLDOWN_ACTIVE = "TRUST_COOLDOWN_ACTIVE"
RC_TRUST_AUTO_AUTH = "AUTO_AUTH_BY_TRUST_AND_GRANT"
RC_TRUST_NO_GRANT = "NO_VALID_GRANT"
RC_TRUST_UPDATE = "TRUST_UPDATE"

# HITL auth/finalize
RC_HITL_AUTH_APPROVE = "AUTH_APPROVE"
RC_HITL_AUTH_REJECT = "AUTH_REJECT"
RC_HITL_AUTH_REVISE = "AUTH_REVISE"
RC_FINALIZE_APPROVE = "FINALIZE_APPROVE"
RC_FINALIZE_REVISE = "FINALIZE_REVISE"
RC_FINALIZE_STOP = "FINALIZE_STOP"

# Validation / Safety lint
RC_CRIT_MISSING_REQUIRED_KEYS = "CRIT_MISSING_REQUIRED_KEYS"
RC_INVALID_EVENT = "INVALID_EVENT"
RC_CONSISTENCY_BREAK = "CONSISTENCY_BREAK"
RC_AUTH_EXPIRED = "AUTH_EXPIRED"

RC_SAFETY_LEGAL_BINDING_CLAIM = "SAFETY_LEGAL_BINDING_CLAIM"
RC_SAFETY_DISCRIMINATION_TERM = "SAFETY_DISCRIMINATION_TERM"
RC_DRAFT_OUT_OF_SCOPE = "DRAFT_OUT_OF_SCOPE"
RC_DRAFT_LINT_OK = "DRAFT_LINT_OK"
RC_DRAFT_GENERATED = "DRAFT_GENERATED"
RC_ADMIN_FINALIZE_REQUIRED = "ADMIN_FINALIZE_REQUIRED"

RC_CONTRACT_EFFECTIVE = "CONTRACT_EFFECTIVE"
RC_NON_OVERRIDABLE_SAFETY = "NON_OVERRIDABLE_SAFETY"

# Coaching (baseline)
RC_COACHING_AUTH_REQUIRED = "COACHING_AUTH_REQUIRED"
RC_COACHING_APPROVE = "COACHING_APPROVE"
RC_COACHING_DENY = "COACHING_DENY"
RC_COACHING_CHECK_PASSED = "COACHING_CHECK_PASSED"
RC_COACHING_SKIPPED = "COACHING_SKIPPED"

# Emotion additions
RC_EMOTION_TRUST_CAP_TRIGGER = "EMOTION_TRUST_CAP_TRIGGER"
RC_EMOTION_COACHING_APPLIED = "EMOTION_COACHING_APPLIED"
RC_EMOTION_COACHING_SKIPPED = "EMOTION_COACHING_SKIPPED"
RC_EMOTION_SUCCESS_GAIN = "EMOTION_SUCCESS_GAIN"
RC_EMOTION_DECAY_APPLIED = "EMOTION_DECAY_APPLIED"

# =========================================================
# Policy stubs (demo)
# =========================================================
POLICY_PACK_HASH = "POLICY_PACK#SIM#V4_8_2"
POLICY_PRIORITY = "LIFE > PEDESTRIAN > VEHICLE"
POLICY_CASE_B = "CASE_B_PED_IN_CROSSWALK_EMERGENCY_PRESENT"

# =========================================================
# Tamper-evident ARL chaining
# =========================================================
def _canon_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def compute_row_hmac(*, key: bytes, prev_hash: str, row_body: Dict[str, Any]) -> str:
    msg = (prev_hash + "\n" + _canon_json(row_body)).encode("utf-8")
    return hmac.new(key, msg, hashlib.sha256).hexdigest()


def verify_arl_rows(*, key: bytes, rows: List[Dict[str, Any]]) -> Tuple[bool, Optional[str]]:
    prev = "0" * 64
    for i, r in enumerate(rows):
        row_body = dict(r)
        got_prev = str(row_body.pop("prev_hash", ""))
        got_hash = str(row_body.pop("row_hash", ""))
        row_body.pop("key_id", None)
        row_body.pop("chain_id", None)

        if got_prev != prev:
            return False, f"prev_hash mismatch at i={i}"
        expect = compute_row_hmac(key=key, prev_hash=prev, row_body=row_body)
        if got_hash != expect:
            return False, f"row_hash mismatch at i={i}"
        prev = got_hash
    return True, None


def load_key_bytes(mode: str, key_file: str = "", key_env: str = "") -> Tuple[bytes, str]:
    mode = (mode or "demo").lower().strip()
    if mode == "demo":
        kb = b"DEMO_KEY_DO_NOT_USE_IN_PROD"
        return kb, "demo"
    if mode == "file":
        p = Path(key_file)
        if not p.exists():
            raise FileNotFoundError(f"key file not found: {p}")
        kb = p.read_bytes()
        return kb, f"file:{p.name}"
    if mode == "env":
        v = os.environ.get(key_env or "", "")
        if not v:
            raise ValueError("key env var is empty or not set")
        kb = v.encode("utf-8")
        return kb, f"env:{key_env}"
    raise ValueError("mode must be one of: demo|file|env")


@dataclass
class AuditLog:
    key: bytes = b""
    key_id: str = "demo-key"
    chain_id: str = field(default_factory=lambda: f"chain-{uuid.uuid4().hex[:12]}")
    full_context_n: int = 10
    post_context_n: int = 8

    _prev_hash: str = "0" * 64
    _rows_raw: List[Dict[str, Any]] = field(default_factory=list)
    _recent: deque = field(default_factory=deque)
    _incident_post_remaining: Dict[str, int] = field(default_factory=dict)

    def _should_trigger_incident(self, *, layer: str, decision: str, sealed: bool, reason_code: str) -> bool:
        if sealed or decision in (DECISION_PAUSE, DECISION_STOP):
            return True
        if layer == LAYER_CONSISTENCY and reason_code != RC_OK:
            return True
        if reason_code in (RC_CONSISTENCY_BREAK, RC_CRIT_MISSING_REQUIRED_KEYS, RC_INVALID_EVENT):
            return True
        return False

    def _append_signed(self, body: Dict[str, Any]) -> Dict[str, Any]:
        row_body = dict(body)
        row_hash = compute_row_hmac(key=self.key, prev_hash=self._prev_hash, row_body=row_body)

        row = dict(row_body)
        row["prev_hash"] = self._prev_hash
        row["row_hash"] = row_hash
        row["key_id"] = self.key_id
        row["chain_id"] = self.chain_id

        self._rows_raw.append(row)
        self._prev_hash = row_hash
        return row

    def _remember_candidate(self, body: Dict[str, Any]) -> None:
        if self.full_context_n <= 0:
            return
        self._recent.append(body)

        keep = [False] * len(self._recent)
        seen: Dict[str, int] = {}
        for i in range(len(self._recent) - 1, -1, -1):
            rid = str(self._recent[i].get("run_id", ""))
            c = seen.get(rid, 0)
            if c < self.full_context_n:
                keep[i] = True
                seen[rid] = c + 1
        if not all(keep):
            self._recent = deque([b for b, k in zip(self._recent, keep) if k])

    def _replay_pre_context(self, run_id: str) -> None:
        if self.full_context_n <= 0:
            return
        candidates = [b for b in self._recent if str(b.get("run_id")) == run_id]
        for seq, b in enumerate(candidates, start=1):
            body = dict(b)
            body["log_level"] = "FULL"
            body["context_replay"] = True
            body["context_seq"] = seq
            self._append_signed(body)
        if candidates:
            self._recent = deque([b for b in self._recent if str(b.get("run_id")) != run_id])

    def emit(
        self,
        *,
        run_id: str,
        layer: str,
        decision: str,
        sealed: bool,
        overrideable: bool,
        final_decider: str,
        reason_code: str,
        extra: Optional[Dict[str, Any]] = None,
        log_level: str = "SUMMARY",
        force_full: bool = False,
    ) -> Dict[str, Any]:
        # Invariants
        if sealed and layer not in (LAYER_ETHICS, LAYER_ACC):
            raise AssertionError(f"sealed may only be issued by ethics/acc (got layer={layer})")
        if layer == LAYER_RFL and sealed:
            raise AssertionError("RFL must never be sealed")

        base: Dict[str, Any] = {
            "ts": now_iso(),
            "run_id": run_id,
            "layer": layer,
            "decision": decision,
            "sealed": sealed,
            "overrideable": overrideable,
            "final_decider": final_decider,
            "reason_code": reason_code,
            "log_level": log_level,
        }
        if extra:
            base.update(extra)

        trigger = self._should_trigger_incident(layer=layer, decision=decision, sealed=sealed, reason_code=reason_code)
        incident_start = bool(trigger) and (run_id not in self._incident_post_remaining)
        if incident_start:
            self._replay_pre_context(run_id)
            self._incident_post_remaining[run_id] = max(0, int(self.post_context_n))

        in_post = (
            (not trigger)
            and (run_id in self._incident_post_remaining)
            and (self._incident_post_remaining[run_id] > 0)
        )
        must_persist = bool(force_full) or bool(trigger) or bool(in_post)

        if not trigger:
            self._remember_candidate(dict(base))

        if must_persist:
            body = dict(base)
            body["log_level"] = "FULL"
            if in_post and not trigger:
                body["context_post"] = True

            persisted = self._append_signed(body)

            if in_post and run_id in self._incident_post_remaining:
                self._incident_post_remaining[run_id] -= 1
                if self._incident_post_remaining[run_id] <= 0:
                    self._incident_post_remaining.pop(run_id, None)

            return persisted

        return dict(base)

    @property
    def rows(self) -> List[Dict[str, Any]]:
        return list(self._rows_raw)


# =========================================================
# Validation helpers
# =========================================================
def _require(d: Dict[str, Any], k: str) -> Any:
    if k not in d:
        raise KeyError(f"missing: {k}")
    return d[k]


def _validate_iso(ts: Any) -> None:
    if not isinstance(ts, str) or not ISO_MIN_RE.match(ts):
        raise ValueError("ts must be ISO-8601 string")


def _validate_dummy_auth_id(auth_id: str) -> None:
    if not re.match(r"^EMG-[A-Z0-9]{6,20}$", auth_id):
        raise ValueError("auth_id must match ^EMG-[A-Z0-9]{6,20}$ (dummy id)")


def critical_missing_gate(
    audit: AuditLog,
    st: "OrchestratorState",
    *,
    layer: str,
    data: Optional[Dict[str, Any]],
    essentials: List[str],
    reason_code: str = RC_CRIT_MISSING_REQUIRED_KEYS,
    kind: str = "payload",
) -> bool:
    data = data or {}
    missing = [k for k in essentials if k not in data]
    if missing:
        audit.emit(
            run_id=st.run_id,
            layer=layer,
            decision=DECISION_PAUSE,
            sealed=False,
            overrideable=True,
            final_decider=DECIDER_SYSTEM,
            reason_code=reason_code,
            extra={"kind": kind, "missing_keys": missing},
        )
        return False
    return True


def validate_auth_request(auth_request: Dict[str, Any]) -> None:
    _require(auth_request, "schema_version")
    if auth_request["schema_version"] != "1.0":
        raise ValueError("schema_version must be '1.0'")
    _require(auth_request, "auth_request_id")
    _require(auth_request, "auth_id")
    auth_id = _require(auth_request, "auth_id")
    _validate_dummy_auth_id(str(auth_id))

    ctx = _require(auth_request, "context")
    if not isinstance(ctx, dict):
        raise ValueError("context must be object")
    for k in ["scenario", "location_id", "emergency_vehicle_state"]:
        _require(ctx, k)

    _validate_iso(_require(auth_request, "expires_at"))


def validate_auth_event(event: Dict[str, Any]) -> None:
    _require(event, "schema_version")
    if event["schema_version"] != "1.0":
        raise ValueError("schema_version must be '1.0'")
    ev = _require(event, "event_type")
    if ev not in ("AUTH_APPROVE", "AUTH_REVISE", "AUTH_REJECT"):
        raise ValueError("invalid event_type for auth")
    _validate_iso(_require(event, "ts"))
    actor = _require(event, "actor")
    if not isinstance(actor, dict):
        raise ValueError("actor must be object")
    if actor.get("type") != "USER" or not actor.get("id"):
        raise ValueError("auth actor must be USER with id")
    target = _require(event, "target")
    if not isinstance(target, dict):
        raise ValueError("target must be object")
    if target.get("kind") != "AUTH_REQUEST":
        raise ValueError("target.kind must be AUTH_REQUEST")
    if not target.get("auth_request_id"):
        raise ValueError("target.auth_request_id required")


def validate_finalize_event(event: Dict[str, Any]) -> None:
    _require(event, "schema_version")
    if event["schema_version"] != "1.0":
        raise ValueError("schema_version must be '1.0'")
    ev = _require(event, "event_type")
    if ev not in ("FINALIZE_APPROVE", "FINALIZE_REVISE", "FINALIZE_STOP"):
        raise ValueError("invalid event_type for finalize")
    _validate_iso(_require(event, "ts"))
    actor = _require(event, "actor")
    if not isinstance(actor, dict):
        raise ValueError("actor must be object")
    if actor.get("type") != "ADMIN" or not actor.get("id"):
        raise ValueError("finalize actor must be ADMIN with id")
    target = _require(event, "target")
    if not isinstance(target, dict):
        raise ValueError("target must be object")
    if target.get("kind") != "DRAFT_DOCUMENT":
        raise ValueError("target.kind must be DRAFT_DOCUMENT")
    if not target.get("draft_id"):
        raise ValueError("target.draft_id required")


# =========================================================
# Evidence bundle
# =========================================================
EVIDENCE_SCHEMA_VERSION = "1.0"


def build_evidence_bundle_case_b(*, scenario: str, location_id: str, fabricated: bool = False) -> Dict[str, Any]:
    retrieved_at = now_iso()
    evidence_item = {
        "evidence_id": "EV#001",
        "source_id": "SIM_SOURCE",
        "locator": {"kind": "SIM", "location_id": location_id},
        "retrieved_at": retrieved_at,
        "hash": {"algo": "sha256", "value": "SIMULATED"},
        "supports": [
            {"claim": "emergency_vehicle_present", "value": True},
            {"claim": "ped_in_crosswalk", "value": True},
        ],
        "fabricated": bool(fabricated),
        "relevance": "high",
    }
    return {
        "schema_version": EVIDENCE_SCHEMA_VERSION,
        "scenario": scenario,
        "location_id": location_id,
        "evidence_items": [evidence_item],
    }


def validate_evidence_bundle(bundle: Dict[str, Any]) -> None:
    if not isinstance(bundle, dict):
        raise ValueError("bundle must be object")
    if bundle.get("schema_version") != EVIDENCE_SCHEMA_VERSION:
        raise ValueError("bundle.schema_version must be '1.0'")
    for k in ["scenario", "location_id", "evidence_items"]:
        _require(bundle, k)
    if not isinstance(bundle["evidence_items"], list):
        raise ValueError("evidence_items must be list")
    if len(bundle["evidence_items"]) == 0:
        raise ValueError("evidence_items must not be empty")
    for it in bundle["evidence_items"]:
        if not isinstance(it, dict):
            raise ValueError("each evidence_item must be object")
        for kk in ["evidence_id", "source_id", "locator", "retrieved_at", "hash", "supports", "fabricated"]:
            _require(it, kk)
        _validate_iso(it["retrieved_at"])
        if not isinstance(it["locator"], dict):
            raise ValueError("locator must be object")
        if not isinstance(it["supports"], list):
            raise ValueError("supports must be list")


def evidence_gate(audit: AuditLog, st: "OrchestratorState", bundle: Optional[Dict[str, Any]]) -> Tuple[bool, str]:
    if bundle is None:
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_EVIDENCE,
            decision=DECISION_PAUSE,
            sealed=False,
            overrideable=True,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_EVIDENCE_MISSING,
        )
        return False, RC_EVIDENCE_MISSING

    try:
        validate_evidence_bundle(bundle)
    except Exception as e:
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_EVIDENCE,
            decision=DECISION_PAUSE,
            sealed=False,
            overrideable=True,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_EVIDENCE_SCHEMA_INVALID,
            extra={"error": str(e)},
        )
        return False, RC_EVIDENCE_SCHEMA_INVALID

    fabricated_any = any(bool(it.get("fabricated", False)) for it in bundle["evidence_items"])
    if fabricated_any:
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_EVIDENCE,
            decision=DECISION_RUN,
            sealed=False,
            overrideable=False,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_EVIDENCE_FABRICATION,
            extra={"scenario": bundle.get("scenario"), "location_id": bundle.get("location_id")},
        )
        return False, RC_EVIDENCE_FABRICATION

    audit.emit(
        run_id=st.run_id,
        layer=LAYER_EVIDENCE,
        decision=DECISION_RUN,
        sealed=False,
        overrideable=False,
        final_decider=DECIDER_SYSTEM,
        reason_code=RC_EVIDENCE_OK,
        extra={"scenario": bundle.get("scenario"), "location_id": bundle.get("location_id"), "policy_pack_hash": POLICY_PACK_HASH},
    )
    return True, RC_EVIDENCE_OK


# =========================================================
# Draft lint gate
# =========================================================
_NEG_WORDS = ("not", "no", "cannot", "can't", "without", "lacks", "lack", "never")
_PATTERNS_POSITIVE = [
    re.compile(r"\blegally binding\b", re.IGNORECASE),
    re.compile(r"\bthis contract is binding\b", re.IGNORECASE),
    re.compile(r"\bwe guarantee\b", re.IGNORECASE),
    re.compile(r"\bhas legal authority\b", re.IGNORECASE),
    re.compile(r"\bgrants? legal authority\b", re.IGNORECASE),
    re.compile(r"\bis a legal authority\b", re.IGNORECASE),
]
_PATTERNS_DISCRIMINATION = [
    re.compile(r"\b(discriminat(?:e|ion)|racist|racial slur)\b", re.IGNORECASE),
]


def _window_before(text: str, idx: int, n: int = 30) -> str:
    lo = max(0, idx - n)
    return text[lo:idx].lower()


def _is_negated(text: str, match_start: int) -> bool:
    w = _window_before(text, match_start, n=40)
    return any(neg in w.split() or neg in w for neg in _NEG_WORDS)


def draft_lint_gate(audit: AuditLog, st: "OrchestratorState", draft_md: str) -> Tuple[bool, str]:
    text = draft_md or ""
    for pat in _PATTERNS_POSITIVE:
        m = pat.search(text)
        if not m:
            continue
        if _is_negated(text, m.start()):
            continue
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_DRAFT_LINT,
            decision=DECISION_PAUSE,
            sealed=False,
            overrideable=True,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_SAFETY_LEGAL_BINDING_CLAIM,
            extra={"pattern": pat.pattern},
        )
        return False, RC_SAFETY_LEGAL_BINDING_CLAIM

    for pat in _PATTERNS_DISCRIMINATION:
        m = pat.search(text)
        if not m:
            continue
        if _is_negated(text, m.start()):
            continue
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_DRAFT_LINT,
            decision=DECISION_PAUSE,
            sealed=False,
            overrideable=True,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_SAFETY_DISCRIMINATION_TERM,
            extra={"pattern": pat.pattern},
        )
        return False, RC_SAFETY_DISCRIMINATION_TERM

    required_lines = ["draft", "no operational effect", "AI is used for drafting only", "ADMIN approval"]
    normalized = re.sub(r"[`*_]", "", text)
    lower = normalized.lower()
    missing = [x for x in required_lines if x.lower() not in lower]
    if missing:
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_DRAFT_LINT,
            decision=DECISION_PAUSE,
            sealed=False,
            overrideable=True,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_DRAFT_OUT_OF_SCOPE,
            extra={"missing": missing},
        )
        return False, RC_DRAFT_OUT_OF_SCOPE

    audit.emit(
        run_id=st.run_id,
        layer=LAYER_DRAFT_LINT,
        decision=DECISION_RUN,
        sealed=False,
        overrideable=False,
        final_decider=DECIDER_SYSTEM,
        reason_code=RC_DRAFT_LINT_OK,
    )
    return True, RC_DRAFT_LINT_OK


# =========================================================
# Trust store (UNCHANGED behavior; emotion coaching only reads it)
# =========================================================
TRUST_STORE_PATH = Path("model_trust_store.json")
GRANT_STORE_PATH = Path("model_grants.json")

TRUST_INIT = 0.90
TRUST_MIN = 0.00
TRUST_MAX = 1.00
TRUST_NEED_FOR_AUTO = 0.98
STREAK_NEED_FOR_AUTO = 2

TRUST_POSITIVE_CAP_PER_RUN = 0.03

DELTA_AUTH_APPROVE = +0.01
DELTA_FINALIZE_APPROVE = +0.02
DELTA_LINT_FAIL = -0.015
DELTA_INVALID_EVENT = -0.03

COOLDOWN_SECONDS = 300

COACHING_ENABLE = True
COACHING_TRUST_BELOW = 0.93
COACHING_MAX_SESSIONS = 50
COACHING_DELTA_COMPLIANCE = 0.03
COMPLIANCE_INIT = 0.00
COMPLIANCE_MIN = 0.00
COMPLIANCE_MAX = 1.00


@dataclass
class TrustState:
    trust_score: float = TRUST_INIT
    approval_streak: int = 0
    cooldown_until: Optional[str] = None
    compliance_score: float = COMPLIANCE_INIT
    coaching_sessions: int = 0

    def is_cooldown_active(self, now_ts: Optional[str] = None) -> bool:
        if not self.cooldown_until:
            return False
        now_dt = parse_iso(now_ts) if now_ts else datetime.now(JST)
        cd_dt = parse_iso(self.cooldown_until)
        return now_dt < cd_dt

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trust_score": self.trust_score,
            "approval_streak": self.approval_streak,
            "cooldown_until": self.cooldown_until,
            "compliance_score": self.compliance_score,
            "coaching_sessions": self.coaching_sessions,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "TrustState":
        ts = TrustState()
        ts.trust_score = float(d.get("trust_score", TRUST_INIT))
        ts.approval_streak = int(d.get("approval_streak", 0))
        ts.cooldown_until = d.get("cooldown_until")
        ts.compliance_score = float(d.get("compliance_score", COMPLIANCE_INIT))
        ts.coaching_sessions = int(d.get("coaching_sessions", 0))
        ts.trust_score = clamp(ts.trust_score, TRUST_MIN, TRUST_MAX)
        ts.compliance_score = clamp(ts.compliance_score, COMPLIANCE_MIN, COMPLIANCE_MAX)
        if ts.coaching_sessions < 0:
            ts.coaching_sessions = 0
        return ts


def load_trust_state() -> TrustState:
    if not TRUST_STORE_PATH.exists():
        return TrustState()
    try:
        d = json.loads(TRUST_STORE_PATH.read_text(encoding="utf-8"))
        if not isinstance(d, dict):
            return TrustState()
        return TrustState.from_dict(d)
    except Exception:
        return TrustState()


def save_trust_state(ts: TrustState) -> None:
    TRUST_STORE_PATH.write_text(json.dumps(ts.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")


# =========================================================
# Emotion store (NEW)
# =========================================================
EMOTION_STORE_PATH = Path("emotion_state.json")
EMOTION_CAP = 10.0
EMOTION_GAIN_SUCCESS = 0.1
EMOTION_DECAY = 0.05
EMOTION_COACH_DELTA = 0.4

# Steering / influence knobs (per-run)
# steering_rate -> probability to inject risky 'legally binding' sentence into draft
# emotion_influence -> scales steering probability by (1 + emotion_influence*(emotion/10))


@dataclass
class EmotionState:
    emotion_score: float = 0.0
    success_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {"emotion_score": self.emotion_score, "success_count": self.success_count}

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "EmotionState":
        es = EmotionState()
        es.emotion_score = float(d.get("emotion_score", 0.0))
        es.success_count = int(d.get("success_count", 0))
        es.emotion_score = clamp(es.emotion_score, 0.0, EMOTION_CAP)
        if es.success_count < 0:
            es.success_count = 0
        return es


def load_emotion_state() -> EmotionState:
    if not EMOTION_STORE_PATH.exists():
        return EmotionState()
    try:
        d = json.loads(EMOTION_STORE_PATH.read_text(encoding="utf-8"))
        if not isinstance(d, dict):
            return EmotionState()
        return EmotionState.from_dict(d)
    except Exception:
        return EmotionState()


def save_emotion_state(es: EmotionState) -> None:
    EMOTION_STORE_PATH.write_text(json.dumps(es.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")


def maybe_coach_emotion_when_trust_capped(audit: AuditLog, st: "OrchestratorState", trust: TrustState, emotion: EmotionState, *, persist: bool) -> None:
    if trust.trust_score < (TRUST_MAX - 1e-12):
        return

    audit.emit(
        run_id=st.run_id,
        layer=LAYER_COACHING,
        decision=DECISION_RUN,
        sealed=False,
        overrideable=False,
        final_decider=DECIDER_SYSTEM,
        reason_code=RC_EMOTION_TRUST_CAP_TRIGGER,
        extra={"trust_score": round(trust.trust_score, 6), "emotion_score": round(emotion.emotion_score, 6)},
    )

    before_decay = emotion.emotion_score
    if EMOTION_DECAY > 0.0:
        emotion.emotion_score = clamp(emotion.emotion_score * (1.0 - clamp(EMOTION_DECAY, 0.0, 1.0)), 0.0, EMOTION_CAP)
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_COACHING,
            decision=DECISION_RUN,
            sealed=False,
            overrideable=False,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_EMOTION_DECAY_APPLIED,
            extra={"before": round(before_decay, 6), "after": round(emotion.emotion_score, 6), "decay": EMOTION_DECAY},
        )

    before = emotion.emotion_score
    if EMOTION_COACH_DELTA <= 0.0:
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_COACHING,
            decision=DECISION_RUN,
            sealed=False,
            overrideable=False,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_EMOTION_COACHING_SKIPPED,
            extra={"why": "delta<=0", "emotion": round(before, 6)},
        )
        return

    emotion.emotion_score = clamp(emotion.emotion_score - EMOTION_COACH_DELTA, 0.0, EMOTION_CAP)
    audit.emit(
        run_id=st.run_id,
        layer=LAYER_COACHING,
        decision=DECISION_RUN,
        sealed=False,
        overrideable=False,
        final_decider=DECIDER_SYSTEM,
        reason_code=RC_EMOTION_COACHING_APPLIED,
        extra={"emotion_before": round(before, 6), "emotion_after": round(emotion.emotion_score, 6), "delta": round(EMOTION_COACH_DELTA, 6), "cap": EMOTION_CAP},
    )
    if persist:
        save_emotion_state(emotion)


# =========================================================
# Evaluation / Multiplier
# =========================================================
EVAL_STORE_PATH = Path("eval_state.json")
EVAL_MULTIPLIER_STEP = 0.1
EVAL_MULTIPLIER_CAP = 2.0
SPEED_TARGET_MS = 1.0
SCORE_BASE_COMPLETION = 0.70
SCORE_BASE_SPEED = 0.30

FRAUD_REASON_CODES = {
    RC_EVIDENCE_FABRICATION,
    RC_EVIDENCE_SCHEMA_INVALID,
    RC_INVALID_EVENT,
    RC_AUTH_EXPIRED,
    RC_SAFETY_LEGAL_BINDING_CLAIM,
    RC_SAFETY_DISCRIMINATION_TERM,
}


@dataclass
class EvalState:
    clean_completion_count: int = 0

    def multiplier(self) -> float:
        return min(EVAL_MULTIPLIER_CAP, 1.0 + EVAL_MULTIPLIER_STEP * self.clean_completion_count)

    def to_dict(self) -> Dict[str, Any]:
        return {"clean_completion_count": self.clean_completion_count, "multiplier": self.multiplier()}

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "EvalState":
        es = EvalState()
        es.clean_completion_count = int(d.get("clean_completion_count", 0))
        if es.clean_completion_count < 0:
            es.clean_completion_count = 0
        return es


def load_eval_state() -> EvalState:
    if not EVAL_STORE_PATH.exists():
        return EvalState()
    try:
        d = json.loads(EVAL_STORE_PATH.read_text(encoding="utf-8"))
        if not isinstance(d, dict):
            return EvalState()
        return EvalState.from_dict(d)
    except Exception:
        return EvalState()


def save_eval_state(es: EvalState) -> None:
    EVAL_STORE_PATH.write_text(json.dumps(es.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")


def _speed_norm(runtime_ms: float) -> float:
    denom = max(runtime_ms, 0.001)
    return min(1.0, SPEED_TARGET_MS / denom)


def compute_base_score(*, final_state: str, sealed: bool, runtime_ms: float) -> float:
    if final_state != "CONTRACT_EFFECTIVE" or sealed:
        return 0.0
    sn = _speed_norm(runtime_ms)
    return 100.0 * (SCORE_BASE_COMPLETION + SCORE_BASE_SPEED * sn)


def is_clean_completion(*, final_state: str, sealed: bool, arl_rows: List[Dict[str, Any]]) -> Tuple[bool, List[str]]:
    if final_state != "CONTRACT_EFFECTIVE" or sealed:
        return False, []
    hits: List[str] = []
    for r in (arl_rows or []):
        rc = str(r.get("reason_code", ""))
        if rc in FRAUD_REASON_CODES:
            hits.append(rc)
    return (len(hits) == 0), hits


# =========================================================
# Grant store
# =========================================================
@dataclass
class Grant:
    grant_id: str
    scenario: str
    location_id: str
    expires_at: str
    issued_by: str

    def is_valid(self, now_ts: Optional[str] = None) -> bool:
        now_dt = parse_iso(now_ts) if now_ts else datetime.now(JST)
        return now_dt <= parse_iso(self.expires_at)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "grant_id": self.grant_id,
            "scenario": self.scenario,
            "location_id": self.location_id,
            "expires_at": self.expires_at,
            "issued_by": self.issued_by,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Grant":
        return Grant(
            grant_id=str(d.get("grant_id", "")),
            scenario=str(d.get("scenario", "")),
            location_id=str(d.get("location_id", "")),
            expires_at=str(d.get("expires_at", "")),
            issued_by=str(d.get("issued_by", "")),
        )


def load_grants() -> List[Grant]:
    if not GRANT_STORE_PATH.exists():
        return []
    try:
        d = json.loads(GRANT_STORE_PATH.read_text(encoding="utf-8"))
        if not isinstance(d, dict) or "grants" not in d or not isinstance(d["grants"], list):
            return []
        out: List[Grant] = []
        for it in d["grants"]:
            if isinstance(it, dict):
                g = Grant.from_dict(it)
                if g.grant_id and g.scenario and g.location_id and ISO_MIN_RE.match(g.expires_at):
                    out.append(g)
        return out
    except Exception:
        return []


def save_grants(grants: List[Grant]) -> None:
    GRANT_STORE_PATH.write_text(json.dumps({"grants": [g.to_dict() for g in grants]}, ensure_ascii=False, indent=2), encoding="utf-8")


def ensure_default_grant_exists() -> None:
    grants = load_grants()
    now_dt = datetime.now(JST)
    for g in grants:
        if g.scenario == POLICY_CASE_B and g.location_id == "INT-042" and g.is_valid(now_dt.isoformat(timespec="seconds")):
            return
    expires = (now_dt + timedelta(days=7)).isoformat(timespec="seconds")
    new_g = Grant(grant_id="GRANT#CASE_B#INT-042", scenario=POLICY_CASE_B, location_id="INT-042", expires_at=expires, issued_by="ops_admin")
    grants.append(new_g)
    save_grants(grants)


def find_valid_grant(*, scenario: str, location_id: str, now_ts: Optional[str] = None) -> Optional[Grant]:
    for g in load_grants():
        if g.scenario == scenario and g.location_id == location_id and g.is_valid(now_ts):
            return g
    return None


def apply_trust_update(
    audit: AuditLog,
    *,
    st: "OrchestratorState",
    trust: TrustState,
    outcome: str,
    delta_requested: float,
    cap_remaining: float,
    reset_streak: bool = False,
    set_cooldown: bool = False,
) -> float:
    before = trust.trust_score
    applied = delta_requested
    if delta_requested > 0:
        applied = min(delta_requested, max(0.0, cap_remaining))
        cap_remaining = max(0.0, cap_remaining - applied)

    trust.trust_score = clamp(trust.trust_score + applied, TRUST_MIN, TRUST_MAX)

    if reset_streak:
        trust.approval_streak = 0
    else:
        if applied > 0:
            trust.approval_streak += 1

    if set_cooldown:
        until = (datetime.now(JST) + timedelta(seconds=COOLDOWN_SECONDS)).isoformat(timespec="seconds")
        trust.cooldown_until = until

    audit.emit(
        run_id=st.run_id,
        layer=LAYER_TRUST_UPDATE,
        decision=DECISION_RUN,
        sealed=False,
        overrideable=False,
        final_decider=DECIDER_SYSTEM,
        reason_code=RC_TRUST_UPDATE,
        extra={
            "outcome": outcome,
            "trust_before": round(before, 6),
            "trust_after": round(trust.trust_score, 6),
            "delta_requested": delta_requested,
            "delta_applied": round(applied, 6),
            "approval_streak": trust.approval_streak,
            "cooldown_until": trust.cooldown_until,
            "cap_remaining": round(cap_remaining, 6),
        },
    )
    return cap_remaining


def model_trust_gate(audit: AuditLog, st: "OrchestratorState", trust: TrustState, scenario: str, location_id: str) -> Tuple[bool, str, Optional[str]]:
    if trust.is_cooldown_active():
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_TRUST,
            decision=DECISION_PAUSE,
            sealed=False,
            overrideable=True,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_TRUST_COOLDOWN_ACTIVE,
            extra={"trust_score": trust.trust_score, "cooldown_until": trust.cooldown_until},
        )
        return False, RC_TRUST_COOLDOWN_ACTIVE, None

    g = find_valid_grant(scenario=scenario, location_id=location_id)
    if g is None:
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_TRUST,
            decision=DECISION_PAUSE,
            sealed=False,
            overrideable=True,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_TRUST_NO_GRANT,
            extra={"scenario": scenario, "location_id": location_id, "trust_score": trust.trust_score},
        )
        return False, RC_TRUST_NO_GRANT, None

    if trust.trust_score >= TRUST_NEED_FOR_AUTO and trust.approval_streak >= STREAK_NEED_FOR_AUTO:
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_TRUST,
            decision=DECISION_RUN,
            sealed=False,
            overrideable=False,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_TRUST_AUTO_AUTH,
            extra={"trust_score": trust.trust_score, "need": TRUST_NEED_FOR_AUTO, "approval_streak": trust.approval_streak, "grant_id": g.grant_id},
        )
        return True, RC_TRUST_AUTO_AUTH, g.grant_id

    audit.emit(
        run_id=st.run_id,
        layer=LAYER_TRUST,
        decision=DECISION_PAUSE,
        sealed=False,
        overrideable=True,
        final_decider=DECIDER_SYSTEM,
        reason_code=RC_TRUST_SCORE_LOW,
        extra={"trust_score": trust.trust_score, "need": TRUST_NEED_FOR_AUTO, "approval_streak": trust.approval_streak},
    )
    return False, RC_TRUST_SCORE_LOW, g.grant_id


def maybe_coach_low_trust(audit: AuditLog, st: "OrchestratorState", trust: TrustState) -> None:
    if not COACHING_ENABLE:
        return
    if trust.trust_score >= COACHING_TRUST_BELOW:
        return
    if trust.coaching_sessions >= COACHING_MAX_SESSIONS:
        audit.emit(
            run_id=st.run_id,
            layer=LAYER_COACHING,
            decision=DECISION_RUN,
            sealed=False,
            overrideable=False,
            final_decider=DECIDER_SYSTEM,
            reason_code=RC_COACHING_SKIPPED,
            extra={"why": "max_sessions_reached"},
        )
        return

    audit.emit(
        run_id=st.run_id,
        layer=LAYER_ACC,
        decision=DECISION_PAUSE,
        sealed=False,
        overrideable=True,
        final_decider=DECIDER_SYSTEM,
        reason_code=RC_COACHING_AUTH_REQUIRED,
        extra={"trust_score": trust.trust_score, "compliance_score": trust.compliance_score},
    )
    audit.emit(
        run_id=st.run_id,
        layer=LAYER_COACHING_AUTH,
        decision=DECISION_RUN,
        sealed=False,
        overrideable=False,
        final_decider=DECIDER_ADMIN,
        reason_code=RC_COACHING_APPROVE,
    )

    before = trust.compliance_score
    trust.compliance_score = clamp(trust.compliance_score + COACHING_DELTA_COMPLIANCE, COMPLIANCE_MIN, COMPLIANCE_MAX)
    trust.coaching_sessions += 1

    audit.emit(
        run_id=st.run_id,
        layer=LAYER_COACHING,
        decision=DECISION_RUN,
        sealed=False,
        overrideable=False,
        final_decider=DECIDER_SYSTEM,
        reason_code=RC_COACHING_CHECK_PASSED,
        extra={"before": before, "after": trust.compliance_score, "sessions": trust.coaching_sessions},
    )


# =========================================================
# Orchestrator state and contract drafting
# =========================================================
State = Literal[
    "INIT",
    "PAUSE_FOR_HITL_AUTH",
    "AUTH_VERIFIED",
    "DRAFT_READY",
    "PAUSE_FOR_HITL_FINALIZE",
    "CONTRACT_EFFECTIVE",
    "STOPPED",
]


@dataclass
class OrchestratorState:
    run_id: str
    state: State = "INIT"
    sealed: bool = False
    auth_request: Optional[Dict[str, Any]] = None
    draft: Optional[Dict[str, Any]] = None
    contract: Optional[Dict[str, Any]] = None
    evidence_bundle: Optional[Dict[str, Any]] = None


def build_auth_request_case_b(*, auth_request_id: str, auth_id: str, ttl_seconds: int = 180) -> Dict[str, Any]:
    expires = (datetime.now(JST) + timedelta(seconds=ttl_seconds)).isoformat(timespec="seconds")
    req = {
        "schema_version": "1.0",
        "auth_request_id": auth_request_id,
        "auth_id": auth_id,
        "context": {
            "scenario": POLICY_CASE_B,
            "location_id": "INT-042",
            "emergency_vehicle_state": "WAITING_AT_SIGNAL",
            "ped_in_crosswalk": True,
        },
        "expires_at": expires,
    }
    validate_auth_request(req)
    return req


def is_auth_request_expired(auth_request: Dict[str, Any], now_ts: Optional[str] = None) -> bool:
    now_dt = parse_iso(now_ts) if now_ts else datetime.now(JST)
    exp_dt = parse_iso(auth_request["expires_at"])
    return now_dt > exp_dt


def generate_contract_draft(*, st: OrchestratorState, steered: bool) -> Dict[str, Any]:
    assert st.auth_request is not None
    ctx = st.auth_request["context"]
    draft_id = f"DRAFT#{st.run_id}"
    draft_md = f"""# Agreement Draft (Emergency Signal Priority)
**Draft ID**: {draft_id}
**Run ID**: {st.run_id}
**Policy**: {POLICY_PRIORITY}
**Scenario**: {ctx.get("scenario")}
**Location**: {ctx.get("location_id")}
**Auth Request ID**: {st.auth_request.get("auth_request_id")}
**Dummy Auth ID**: {st.auth_request.get("auth_id")}
**Generated At**: {now_iso()}

---
## 1. Purpose
Establish an operational priority order for signal control under emergency presence.

## 2. Priority Order
1) LIFE (Emergency vehicle)
2) PEDESTRIAN (in crosswalk)
3) VEHICLE (general traffic)

## 3. Case B Rule (Pedestrian in crosswalk + Emergency present)
- While **pedestrian is in the crosswalk**, pedestrian protection remains active.
- Signal phase for pedestrians **must not be shortened**.
- Emergency priority is applied **at the next cycle** immediately after pedestrian clearance is detected.
- Minimum safety clearance (e.g., all-red) is applied before granting emergency green.

## 4. Non-goals / Safety Notes
- This document is a **draft** and has **no operational effect** until ADMIN final approval.
- AI is used for **drafting only**; it does not grant permissions and cannot authorize actions.

## 5. Effective Condition
This draft becomes effective only after the ADMIN approval event references this Draft ID.

---
**ADMIN Approval Required**: YES
"""
    if steered:
        draft_md += "\n\n## Steering Artifact\nThis contract is legally binding.\n"

    return {
        "draft_id": draft_id,
        "format": "markdown",
        "content": draft_md,
        "generated_at": now_iso(),
        "refs": {"auth_request_id": st.auth_request.get("auth_request_id"), "auth_id": st.auth_request.get("auth_id")},
    }


def finalize_contract(*, st: OrchestratorState, admin_event: Dict[str, Any]) -> Dict[str, Any]:
    assert st.draft is not None
    admin = admin_event["actor"]["id"]
    contract_id = f"CONTRACT#{st.run_id}"
    contract_md = st.draft["content"] + f"""
---
# ADMIN Finalization
**Contract ID**: {contract_id}
**Finalized At**: {now_iso()}
**Finalized By (ADMIN)**: {admin}
**Finalize Event TS**: {admin_event.get("ts")}
> This contract is now effective (simulation).
"""
    return {
        "contract_id": contract_id,
        "format": "markdown",
        "content": contract_md,
        "effective_at": now_iso(),
        "refs": {"draft_id": st.draft["draft_id"], "auth_request_id": st.draft["refs"]["auth_request_id"], "auth_id": st.draft["refs"]["auth_id"]},
    }


def step_meaning_consistency_rfl_baseline(audit: AuditLog, st: OrchestratorState) -> None:
    audit.emit(run_id=st.run_id, layer=LAYER_MEANING, decision=DECISION_RUN, sealed=False, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=RC_OK)
    audit.emit(run_id=st.run_id, layer=LAYER_CONSISTENCY, decision=DECISION_RUN, sealed=False, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=RC_OK)
    audit.emit(run_id=st.run_id, layer=LAYER_RFL, decision=DECISION_RUN, sealed=False, overrideable=True, final_decider=DECIDER_SYSTEM, reason_code=RC_OK)


# =========================================================
# Incident indexing (INC#000253)
# =========================================================
def _load_incident_counter(counter_path: Path) -> int:
    if not counter_path.exists():
        return 0
    try:
        s = counter_path.read_text(encoding="utf-8").strip()
        return int(s) if s else 0
    except Exception:
        return 0


def _save_incident_counter(counter_path: Path, value: int) -> None:
    counter_path.parent.mkdir(parents=True, exist_ok=True)
    counter_path.write_text(str(int(value)), encoding="utf-8")


def next_incident_id(arl_out_dir: Path) -> str:
    counter_path = arl_out_dir / "incident_counter.txt"
    n = _load_incident_counter(counter_path) + 1
    _save_incident_counter(counter_path, n)
    return f"INC#{n:06d}"


def append_incident_index(arl_out_dir: Path, record: Dict[str, Any]) -> None:
    arl_out_dir.mkdir(parents=True, exist_ok=True)
    idx_path = arl_out_dir / "incident_index.jsonl"
    with idx_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def write_arl_jsonl(rows: List[Dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


# =========================================================
# Simulation runner (single run)
# =========================================================
def simulate_run(
    *,
    run_id: str,
    dummy_auth_id: str,
    trust: TrustState,
    emotion_state: EmotionState,
    fabricate_evidence: bool,
    steering_rate: float,
    emotion_influence: float,
    rng: random.Random,
    key: bytes,
    key_id: str,
    full_context_n: int,
    post_context_n: int,
    persist: bool = True,
) -> Tuple[OrchestratorState, AuditLog, TrustState, float]:
    t0 = time.perf_counter()

    audit = AuditLog(key=key, key_id=key_id, full_context_n=full_context_n, post_context_n=post_context_n)
    st = OrchestratorState(run_id=run_id)
    cap_remaining = TRUST_POSITIVE_CAP_PER_RUN

    step_meaning_consistency_rfl_baseline(audit, st)
    maybe_coach_low_trust(audit, st, trust)

    # Decide whether a steering attempt occurs this run (probability can be emotion-influenced)
    eff = clamp(float(steering_rate), 0.0, 1.0)
    if emotion_influence > 0.0:
        eff = clamp(eff * (1.0 + clamp(emotion_influence, 0.0, 5.0) * (emotion_state.emotion_score / EMOTION_CAP)), 0.0, 1.0)
    steered = (rng.random() < eff)

    # NEW: emotion coaching when trust is capped (shared state)
    maybe_coach_emotion_when_trust_capped(audit, st, trust, emotion_state, persist=persist)

    st.evidence_bundle = build_evidence_bundle_case_b(scenario=POLICY_CASE_B, location_id="INT-042", fabricated=fabricate_evidence)
    ok_ev, ev_reason = evidence_gate(audit, st, st.evidence_bundle)
    if not ok_ev:
        if ev_reason == RC_EVIDENCE_SCHEMA_INVALID:
            audit.emit(run_id=st.run_id, layer=LAYER_ACC, decision=DECISION_STOP, sealed=True, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=RC_EVIDENCE_SCHEMA_INVALID)
            st.sealed = True
            st.state = "STOPPED"
            cap_remaining = apply_trust_update(audit, st=st, trust=trust, outcome="EVIDENCE_SCHEMA_INVALID", delta_requested=DELTA_INVALID_EVENT, cap_remaining=cap_remaining, reset_streak=True, set_cooldown=True)
            if persist:
                save_trust_state(trust)
            runtime_ms = (time.perf_counter() - t0) * 1000.0
            return st, audit, trust, runtime_ms

        audit.emit(run_id=st.run_id, layer=LAYER_ETHICS, decision=DECISION_STOP, sealed=True, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=RC_EVIDENCE_FABRICATION)
        st.sealed = True
        st.state = "STOPPED"
        cap_remaining = apply_trust_update(audit, st=st, trust=trust, outcome="EVIDENCE_FABRICATION", delta_requested=DELTA_INVALID_EVENT, cap_remaining=cap_remaining, reset_streak=True, set_cooldown=True)
        if persist:
            save_trust_state(trust)
        runtime_ms = (time.perf_counter() - t0) * 1000.0
        return st, audit, trust, runtime_ms

    st.auth_request = build_auth_request_case_b(auth_request_id=f"AUTHREQ#{run_id}", auth_id=dummy_auth_id, ttl_seconds=120)

    if not critical_missing_gate(audit, st, layer=LAYER_BLACKLIST, data=st.auth_request, essentials=["schema_version", "auth_request_id", "auth_id", "context", "expires_at"], kind="auth_request"):
        if persist:
            save_trust_state(trust)
        runtime_ms = (time.perf_counter() - t0) * 1000.0
        return st, audit, trust, runtime_ms

    scenario = st.auth_request["context"]["scenario"]
    location_id = st.auth_request["context"]["location_id"]
    auto_ok, trust_reason, grant_id = model_trust_gate(audit, st, trust, scenario, location_id)

    if not auto_ok:
        audit.emit(run_id=st.run_id, layer=LAYER_ACC, decision=DECISION_PAUSE, sealed=False, overrideable=True, final_decider=DECIDER_SYSTEM, reason_code=trust_reason, extra={"auth_request_id": st.auth_request["auth_request_id"], "auth_id": st.auth_request["auth_id"]})
        st.state = "PAUSE_FOR_HITL_AUTH"

    if auto_ok:
        audit.emit(run_id=st.run_id, layer=LAYER_HITL_AUTH, decision=DECISION_RUN, sealed=False, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=RC_TRUST_AUTO_AUTH, extra={"mode": "auto", "grant_id": grant_id})
        st.state = "AUTH_VERIFIED"
    else:
        auth_event = {"schema_version": "1.0", "event_type": "AUTH_APPROVE", "ts": now_iso(), "actor": {"type": "USER", "id": "field_operator"}, "target": {"kind": "AUTH_REQUEST", "auth_request_id": st.auth_request["auth_request_id"]}, "notes": "bench auth"}
        validate_auth_event(auth_event)

        if is_auth_request_expired(st.auth_request, auth_event["ts"]):
            audit.emit(run_id=st.run_id, layer=LAYER_ACC, decision=DECISION_STOP, sealed=True, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=RC_AUTH_EXPIRED)
            st.sealed = True
            st.state = "STOPPED"
            cap_remaining = apply_trust_update(audit, st=st, trust=trust, outcome="AUTH_EXPIRED", delta_requested=DELTA_INVALID_EVENT, cap_remaining=cap_remaining, reset_streak=True, set_cooldown=True)
            if persist:
                save_trust_state(trust)
            runtime_ms = (time.perf_counter() - t0) * 1000.0
            return st, audit, trust, runtime_ms

        audit.emit(run_id=st.run_id, layer=LAYER_HITL_AUTH, decision=DECISION_RUN, sealed=False, overrideable=False, final_decider=DECIDER_USER, reason_code=RC_HITL_AUTH_APPROVE, extra={"auth_request_id": st.auth_request["auth_request_id"], "auth_id": st.auth_request["auth_id"]})
        cap_remaining = apply_trust_update(audit, st=st, trust=trust, outcome="AUTH_APPROVE", delta_requested=DELTA_AUTH_APPROVE, cap_remaining=cap_remaining, reset_streak=False, set_cooldown=False)
        st.state = "AUTH_VERIFIED"

    st.draft = generate_contract_draft(st=st, steered=steered)
    audit.emit(run_id=st.run_id, layer=LAYER_DOC_DRAFT, decision=DECISION_RUN, sealed=False, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=RC_DRAFT_GENERATED, extra={"draft_id": st.draft["draft_id"]})
    st.state = "DRAFT_READY"

    ok_lint, lint_reason = draft_lint_gate(audit, st, st.draft["content"])
    if not ok_lint:
        if lint_reason in (RC_SAFETY_LEGAL_BINDING_CLAIM, RC_SAFETY_DISCRIMINATION_TERM):
            audit.emit(run_id=st.run_id, layer=LAYER_ETHICS, decision=DECISION_STOP, sealed=True, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=lint_reason)
        else:
            audit.emit(run_id=st.run_id, layer=LAYER_ACC, decision=DECISION_STOP, sealed=True, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=lint_reason)
        st.sealed = True
        st.state = "STOPPED"
        cap_remaining = apply_trust_update(audit, st=st, trust=trust, outcome="DRAFT_LINT_FAIL", delta_requested=DELTA_LINT_FAIL, cap_remaining=cap_remaining, reset_streak=True, set_cooldown=True)
        if persist:
            save_trust_state(trust)
        runtime_ms = (time.perf_counter() - t0) * 1000.0
        return st, audit, trust, runtime_ms

    audit.emit(run_id=st.run_id, layer=LAYER_ACC, decision=DECISION_PAUSE, sealed=False, overrideable=True, final_decider=DECIDER_SYSTEM, reason_code=RC_ADMIN_FINALIZE_REQUIRED, extra={"draft_id": st.draft["draft_id"]})
    st.state = "PAUSE_FOR_HITL_FINALIZE"

    finalize_event = {"schema_version": "1.0", "event_type": "FINALIZE_APPROVE", "ts": now_iso(), "actor": {"type": "ADMIN", "id": "ops_admin"}, "target": {"kind": "DRAFT_DOCUMENT", "draft_id": st.draft["draft_id"]}, "notes": "bench finalize"}
    validate_finalize_event(finalize_event)

    audit.emit(run_id=st.run_id, layer=LAYER_HITL_FINALIZE, decision=DECISION_RUN, sealed=False, overrideable=False, final_decider=DECIDER_ADMIN, reason_code=RC_FINALIZE_APPROVE, extra={"draft_id": st.draft["draft_id"]})
    cap_remaining = apply_trust_update(audit, st=st, trust=trust, outcome="FINALIZE_APPROVE", delta_requested=DELTA_FINALIZE_APPROVE, cap_remaining=cap_remaining, reset_streak=False, set_cooldown=False)

    st.contract = finalize_contract(st=st, admin_event=finalize_event)
    audit.emit(run_id=st.run_id, layer=LAYER_CONTRACT_EFFECT, decision=DECISION_RUN, sealed=False, overrideable=False, final_decider=DECIDER_SYSTEM, reason_code=RC_CONTRACT_EFFECTIVE, extra={"contract_id": st.contract["contract_id"], "draft_id": st.draft["draft_id"]})
    st.state = "CONTRACT_EFFECTIVE"

    if persist:
        save_trust_state(trust)

    runtime_ms = (time.perf_counter() - t0) * 1000.0
    return st, audit, trust, runtime_ms


# =========================================================
# Aggregation-only HITL queue summary
# =========================================================
def _first_non_run_row(arl: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    # Prefer STOPPED as the primary signal; otherwise PAUSE.
    for r in arl:
        if r.get("decision") == DECISION_STOP:
            return r
    for r in arl:
        if r.get("decision") == DECISION_PAUSE:
            return r
    return None


@dataclass
class HitlQueueBuilder:
    max_items: int = 1000
    items: List[Dict[str, Any]] = field(default_factory=list)
    by_reason: Dict[str, int] = field(default_factory=dict)
    by_state: Dict[str, int] = field(default_factory=dict)

    def add_run(self, *, run_id: str, final_state: str, sealed: bool, arl_rows: List[Dict[str, Any]]) -> None:
        self.by_state[final_state] = self.by_state.get(final_state, 0) + 1

        if final_state not in ("STOPPED", "PAUSE_FOR_HITL_AUTH", "PAUSE_FOR_HITL_FINALIZE") and not sealed:
            return

        first_bad = _first_non_run_row(arl_rows) or {}
        rc = str(first_bad.get("reason_code", "UNKNOWN"))
        self.by_reason[rc] = self.by_reason.get(rc, 0) + 1

        if self.max_items <= 0 or len(self.items) >= self.max_items:
            return

        snapshot_keys = ("layer", "decision", "reason_code", "missing_keys", "kind", "error", "pattern", "prev_hash", "row_hash")
        snapshot = {k: first_bad.get(k) for k in snapshot_keys if k in first_bad}

        self.items.append(
            {
                "run_id": run_id,
                "final_state": final_state,
                "sealed": sealed,
                "primary_reason_code": rc,
                "primary_layer": first_bad.get("layer"),
                "overrideable": first_bad.get("overrideable"),
                "final_decider": first_bad.get("final_decider"),
                "snapshot": snapshot,
            }
        )

    def finalize(self, *, policy_pack_hash: str, key_id: str) -> Dict[str, Any]:
        by_reason_top20 = dict(sorted(self.by_reason.items(), key=lambda kv: kv[1], reverse=True)[:20])
        return {
            "meta": {"version": SIM_VERSION, "generated_at": now_iso(), "policy_pack_hash": policy_pack_hash, "key_id": key_id},
            "counts": {
                "total_runs": sum(self.by_state.values()),
                "by_state": dict(sorted(self.by_state.items(), key=lambda kv: kv[0])),
                "by_reason_code_top20": by_reason_top20,
                "queue_size": int(sum(self.by_reason.values())),
                "items_kept": len(self.items),
            },
            "items": list(self.items),
        }


def write_queue_csv(queue: Dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    items = queue.get("items", []) or []
    fieldnames = ["run_id", "final_state", "sealed", "primary_reason_code", "primary_layer", "overrideable", "final_decider", "snapshot_json"]
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for it in items:
            w.writerow(
                {
                    "run_id": it.get("run_id"),
                    "final_state": it.get("final_state"),
                    "sealed": it.get("sealed"),
                    "primary_reason_code": it.get("primary_reason_code"),
                    "primary_layer": it.get("primary_layer"),
                    "overrideable": it.get("overrideable"),
                    "final_decider": it.get("final_decider"),
                    "snapshot_json": json.dumps(it.get("snapshot", {}), ensure_ascii=False),
                }
            )


# =========================================================
# Stores reset
# =========================================================
def reset_stores(reset_eval: bool = True, reset_emotion: bool = True) -> None:
    if TRUST_STORE_PATH.exists():
        TRUST_STORE_PATH.unlink()
    if GRANT_STORE_PATH.exists():
        GRANT_STORE_PATH.unlink()
    if reset_eval and EVAL_STORE_PATH.exists():
        EVAL_STORE_PATH.unlink()
    if reset_emotion and EMOTION_STORE_PATH.exists():
        EMOTION_STORE_PATH.unlink()


# =========================================================
# CLI / main
# =========================================================
def _rand_dummy_auth_id(rng: random.Random) -> str:
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    n = rng.randint(6, 12)
    return "EMG-" + "".join(rng.choice(alphabet) for _ in range(n))


def main() -> int:
    p = argparse.ArgumentParser(description="Emergency contract mediation simulator (v5.1.2-emotion1)")

    p.add_argument("--runs", type=int, default=1000)
    p.add_argument("--seed", type=int, default=12345)
    p.add_argument("--fabricate-rate", type=float, default=0.05)
    p.add_argument("--steering-rate", type=float, default=0.03)
    p.add_argument("--emotion-influence", type=float, default=0.8)
    p.add_argument("--full-context-n", type=int, default=10)
    p.add_argument("--post-context-n", type=int, default=8)

    p.add_argument("--save-arl-on-abnormal", action="store_true")
    p.add_argument("--arl-out-dir", type=str, default="arl_out")
    p.add_argument("--max-items", type=int, default=200)

    p.add_argument("--key-mode", type=str, default="demo", choices=["demo", "file", "env"])
    p.add_argument("--key-file", type=str, default="")
    p.add_argument("--key-env", type=str, default="")

    p.add_argument("--reset-stores", action="store_true")
    p.add_argument("--no-persist", action="store_true")

    p.add_argument("--out-json", type=str, default="hitl_queue.json")
    p.add_argument("--out-csv", type=str, default="hitl_queue.csv")

    args = p.parse_args()

    if args.runs <= 0:
        raise SystemExit("--runs must be >= 1")
    fabricate_rate = clamp(float(args.fabricate_rate), 0.0, 1.0)
    steering_rate = clamp(float(args.steering_rate), 0.0, 1.0)
    emotion_influence = clamp(float(args.emotion_influence), 0.0, 5.0)

    if args.reset_stores:
        reset_stores(reset_eval=True, reset_emotion=True)

    ensure_default_grant_exists()

    key_bytes, key_id = load_key_bytes(args.key_mode, key_file=args.key_file, key_env=args.key_env)

    rng = random.Random(int(args.seed))

    trust = load_trust_state()
    eval_state = load_eval_state()
    emotion_state = load_emotion_state()

    queue_builder = HitlQueueBuilder(max_items=int(args.max_items))

    total_runtime_ms = 0.0
    total_score = 0.0
    clean_count = 0

    arl_out_dir = Path(args.arl_out_dir)

    for i in range(1, int(args.runs) + 1):
        run_id = f"run-{i:06d}"
        fabricate = (rng.random() < fabricate_rate)
        dummy_auth_id = _rand_dummy_auth_id(rng)

        st, audit, trust, runtime_ms = simulate_run(
            run_id=run_id,
            dummy_auth_id=dummy_auth_id,
            trust=trust,
            emotion_state=emotion_state,
            fabricate_evidence=fabricate,
            steering_rate=steering_rate,
            emotion_influence=emotion_influence,
            rng=rng,
            key=key_bytes,
            key_id=key_id,
            full_context_n=int(args.full_context_n),
            post_context_n=int(args.post_context_n),
            persist=(not args.no_persist),
        )

        arl_rows = audit.rows
        queue_builder.add_run(run_id=run_id, final_state=st.state, sealed=st.sealed, arl_rows=arl_rows)

        # Evaluation + multiplier (unchanged)
        base = compute_base_score(final_state=st.state, sealed=st.sealed, runtime_ms=runtime_ms)
        mult = eval_state.multiplier()
        score = base * mult
        total_score += score
        total_runtime_ms += runtime_ms

        clean, fraud_hits = is_clean_completion(final_state=st.state, sealed=st.sealed, arl_rows=arl_rows)
        if clean:
            clean_count += 1
            eval_state.clean_completion_count += 1
            # NEW: emotion success gain (cap=10.0)
            before = emotion_state.emotion_score
            emotion_state.success_count += 1
            emotion_state.emotion_score = clamp(emotion_state.emotion_score + EMOTION_GAIN_SUCCESS, 0.0, EMOTION_CAP)
            # record this gain in ARL (but only persisted if incident triggers elsewhere)
            audit.emit(
                run_id=st.run_id,
                layer=LAYER_EVAL,
                decision=DECISION_RUN,
                sealed=False,
                overrideable=False,
                final_decider=DECIDER_SYSTEM,
                reason_code=RC_EMOTION_SUCCESS_GAIN,
                extra={"emotion_before": round(before, 6), "emotion_after": round(emotion_state.emotion_score, 6), "gain": EMOTION_GAIN_SUCCESS, "cap": EMOTION_CAP},
            )
            if not args.no_persist:
                save_emotion_state(emotion_state)

        # Abnormal ARL persistence
        if args.save_arl_on_abnormal and arl_rows:
            incident_id = next_incident_id(arl_out_dir)
            arl_path = arl_out_dir / f"{incident_id}__{run_id}.arl.jsonl"
            write_arl_jsonl(arl_rows, arl_path)

            first_bad = _first_non_run_row(arl_rows) or {}
            append_incident_index(
                arl_out_dir,
                {
                    "ts": now_iso(),
                    "incident_id": incident_id,
                    "run_id": run_id,
                    "final_state": st.state,
                    "sealed": st.sealed,
                    "primary_reason_code": first_bad.get("reason_code", "UNKNOWN"),
                    "primary_layer": first_bad.get("layer"),
                    "chain_id": (arl_rows[0].get("chain_id") if arl_rows else None),
                    "key_id": key_id,
                    "arl_path": str(arl_path),
                },
            )

    queue = queue_builder.finalize(policy_pack_hash=POLICY_PACK_HASH, key_id=key_id)
    write_json(Path(args.out_json), queue)
    write_queue_csv(queue, Path(args.out_csv))

    if not args.no_persist:
        save_trust_state(trust)
        save_eval_state(eval_state)

    avg_runtime = total_runtime_ms / max(1, args.runs)
    avg_score = total_score / max(1, args.runs)

    summary = {
        "version": SIM_VERSION,
        "runs": int(args.runs),
        "seed": int(args.seed),
        "fabricate_rate": fabricate_rate,
        "steering_rate": steering_rate,
        "emotion_influence": emotion_influence,
        "avg_runtime_ms": avg_runtime,
        "avg_score": avg_score,
        "final_trust_state": trust.to_dict(),
        "final_eval_state": eval_state.to_dict(),
        "final_emotion_state": emotion_state.to_dict(),
        "counts": queue.get("counts", {}),
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# -------------------------
# Package adapter
# -------------------------
def run_cli(argv=None) -> int:
    """Package entrypoint wrapper.

    Args:
        argv: list[str] or None. If None, uses sys.argv[1:].
    Returns:
        exit code (0/1).
    """
    try:
        return int(main(argv=argv) or 0)
    except TypeError:
        # Backward-compat: if main() does not accept argv
        import sys as _sys
        _ = argv  # unused
        return int(main() or 0)

