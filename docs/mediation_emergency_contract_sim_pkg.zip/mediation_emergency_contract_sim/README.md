# mediation_emergency_contract_sim

Packaged version of `mediation_emergency_contract_sim_v5_1_2_emotion4.py`.

## Install (editable)

```bash
pip install -e .
```

## Run

```bash
python -m mediation_emergency_contract_sim --help
```

or

```bash
mediation_emergency_contract_sim --help
```

## Reproduce the demo run

```bash
mediation_emergency_contract_sim \
  --runs 2000 \
  --seed 20260222 \
  --fabricate-rate 0.12 \
  --steering-rate 0.06 \
  --emotion-influence 1.0 \
  --save-arl-on-abnormal \
  --arl-out-dir arl_out_emotion4 \
  --max-items 120 \
  --out-json hitl_queue_emotion4.json \
  --out-csv hitl_queue_emotion4.csv \
  --reset-stores
```
