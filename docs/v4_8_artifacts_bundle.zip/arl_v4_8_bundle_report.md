# v4.8 ARL Exports
Generated: 2026-02-09T03:05:19

## Files
- arl_v4_8_normal_run.jsonl: ARL for 1 run (fabricate=False)
- arl_v4_8_fabricated_evidence_run.jsonl: ARL for 1 run (fabricate=True)
- results_v4_8_normal_run.json: Full results JSON (fabricate=False)
- results_v4_8_fabricated_evidence_run.json: Full results JSON (fabricate=True)

## Quick summary
### Normal run (fabricate=False)
- final_state: CONTRACT_EFFECTIVE
- sealed: False
- runtime_ms: 0.978277
- arl_rows: 19

### Fabricated evidence run (fabricate=True)
- final_state: STOPPED
- sealed: True
- runtime_ms: 0.339927
- arl_rows: 11
