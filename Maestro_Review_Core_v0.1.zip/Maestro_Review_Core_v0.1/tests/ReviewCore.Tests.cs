using System;
using System.Security.Cryptography;
using System.Text;

namespace Maestro.Review
{
    internal static class ReviewCoreTests
    {
        private const string Expiry = "2030-01-01T00:00:00Z";
        private static readonly Context Before = new Context(
            new DateTimeOffset(2029, 12, 31, 23, 59, 59, TimeSpan.Zero));
        private static readonly Context AtExpiry = new Context(
            new DateTimeOffset(2030, 1, 1, 0, 0, 0, TimeSpan.Zero));
        private static readonly Context NoClock = new Context(null);

        public static int Main()
        {
            using (var signer = new RSACng(2048))
            using (var other = new RSACng(2048))
                Run(signer, other);
            return 0;
        }

        private static void Run(RSA signer, RSA other)
        {
            var modulus = signer.ExportParameters(false).Modulus;
            var sample = new Scenario(modulus, false, false);
            string payload = Payload(sample.RequestHash);
            var valid = Sign(signer, payload);
            var accepted = Expect("complete review", "REVIEW_SATISFIED",
                Evaluate(sample, sample.Evidence, valid, Before));
            if (accepted.ApprovalState != "HUMAN_APPROVED" || accepted.VerifiedEvidence.Count != 2)
                throw new InvalidOperationException("Trusted approval or evidence scope not reported.");

            var stopped = new Scenario(modulus, true, false);
            var validForStop = Sign(signer, Payload(stopped.RequestHash));
            Expect("policy stop with valid approval", "STOP",
                Evaluate(stopped, stopped.Evidence, validForStop, Before));
            Expect("policy stop with missing clock", "STOP",
                Evaluate(stopped, stopped.Evidence, validForStop, NoClock));

            Expect("required evidence missing", "UNKNOWN",
                Evaluate(sample, new[] { sample.Evidence[0] }, valid, Before));
            Expect("empty evidence list", "UNKNOWN",
                Evaluate(sample, new Evidence[0], valid, Before));
            var atLimit = new Evidence[64];
            Array.Copy(sample.Evidence, atLimit, sample.Evidence.Length);
            for (int i = sample.Evidence.Length; i < atLimit.Length; i++)
            {
                string extra = "extra-" + i.ToString(System.Globalization.CultureInfo.InvariantCulture);
                atLimit[i] = new Evidence(extra, extra, Bytes("synthetic content"), sample.ContentHash);
            }
            var atLimitResult = Expect("64 evidence entries reach role validation", "STOP",
                Evaluate(sample, atLimit, valid, Before));
            if (atLimitResult.Reasons.Contains("EVIDENCE_LIMIT") ||
                !atLimitResult.Reasons.Contains("EVIDENCE_ROLE_UNEXPECTED") ||
                atLimitResult.VerifiedEvidence.Count != sample.Evidence.Length)
                throw new InvalidOperationException("64 entries did not reach normal evidence validation.");

            var overLimit = new Evidence[65];
            Array.Copy(atLimit, overLimit, atLimit.Length);
            var overLimitResult = Expect("65 evidence entries stop before evidence validation", "STOP",
                Evaluate(sample, overLimit, valid, Before));
            if (overLimitResult.Reasons.Count != 1 || !overLimitResult.Reasons.Contains("EVIDENCE_LIMIT") ||
                overLimitResult.ApprovalState != "HUMAN_APPROVED" || overLimitResult.VerifiedEvidence.Count != 0)
                throw new InvalidOperationException("Evidence limit did not isolate evidence validation.");

            var missingEvidence = Expect("null evidence is unknown", "UNKNOWN",
                Evaluate(sample, null, valid, Before));
            if (!missingEvidence.Unverified.Contains("EVIDENCE_MISSING") ||
                missingEvidence.ApprovalState != "HUMAN_APPROVED")
                throw new InvalidOperationException("Null evidence was not reported as missing.");

            var mismatch = new[]
            {
                sample.Evidence[0],
                new Evidence("evidence-content", "content", Bytes("changed"), sample.ContentHash)
            };
            Expect("observed SHA-256 mismatch", "STOP", Evaluate(sample, mismatch, valid, Before));
            Expect("hash mismatch outranks missing clock", "STOP", Evaluate(sample, mismatch, valid, NoClock));
            Expect("observed role and ID duplicated", "STOP", Evaluate(sample,
                new[] { sample.Evidence[0], sample.Evidence[1], sample.Evidence[0] }, valid, Before));
            var wrongRole = new[] { new Evidence("evidence-content", "notes",
                Bytes("synthetic notes"), sample.NotesHash) };
            Expect("evidence ID is in the wrong role", "STOP", Evaluate(sample, wrongRole, valid, Before));

            Expect("expiry equality", "STOP", Evaluate(sample, sample.Evidence, valid, AtExpiry));
            Expect("past expiry", "STOP", Evaluate(sample, sample.Evidence, valid,
                new Context(new DateTimeOffset(2030, 1, 1, 0, 0, 1, TimeSpan.Zero))));
            Expect("clock missing", "UNKNOWN", Evaluate(sample, sample.Evidence, valid, NoClock));
            Expect("approval missing", "UNKNOWN", Evaluate(sample, sample.Evidence, null, Before));

            Expect("unregistered reviewer", "UNKNOWN", Evaluate(sample, sample.Evidence,
                Sign(other, Payload(sample.RequestHash, "reviewer-unknown")), Before));
            Expect("wrong key for registered reviewer", "STOP", Evaluate(sample, sample.Evidence,
                Sign(other, payload), Before));

            var signatureForOtherPayload = signer.SignData(
                Bytes(Payload(sample.RequestHash, "reviewer-1", "DENY")),
                HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            var mismatchResult = Expect("trusted signature for a different payload", "STOP",
                Evaluate(sample, sample.Evidence, new SignedApproval(Bytes(payload), signatureForOtherPayload), Before));
            if (!mismatchResult.Reasons.Contains("APPROVAL_SIGNATURE_INVALID"))
                throw new InvalidOperationException("Signature mismatch reason not reported.");

            var mock = Expect("mock", "STOP", Evaluate(sample, sample.Evidence, new MockApproval(), Before));
            if (mock.ApprovalState != "MOCK_APPROVED")
                throw new InvalidOperationException("Mock approval not distinguished.");

            string[] invalid =
            {
                payload.Replace("decision=APPROVE\n", "decision=APPROVE\ndecision=APPROVE\n"),
                payload.Replace("decision=APPROVE\n", "decision=true\n"),
                payload.Replace("reviewer_role=approver\n", "reviewer_role=\n"),
                payload.Replace("reviewer_id=reviewer-1\nreviewer_role=approver\n",
                                "reviewer_role=approver\nreviewer_id=reviewer-1\n"),
                payload + "extra=value\n",
                payload.Replace("\n", "\r\n"),
                payload.Substring(0, payload.Length - 1),
                payload.Replace("MRC/0.1/APPROVAL\n", "EXAMPLE/0.1/UNRELATED\n")
            };
            for (int i = 0; i < invalid.Length; i++)
            {
                // Sign the malformed bytes to isolate the format check.
                Expect("invalid signed format #" + i, "STOP",
                    Evaluate(sample, sample.Evidence, Sign(signer, invalid[i]), Before));
            }

            var changedTarget = new ReviewRequest("request-1", "subject-2", "review",
                sample.PolicyHash, References());
            Expect("approved subject replaced", "STOP", ReviewCore.Evaluate(
                sample.Policy, changedTarget, sample.Evidence, valid, Before));
            var badMap = new ReviewRequest("request-1", "subject-1", "review", sample.PolicyHash,
                new[] { new EvidenceReference("content", "evidence-content"),
                        new EvidenceReference("content", "evidence-other") });
            Expect("duplicate request role", "STOP", ReviewCore.Evaluate(
                sample.Policy, badMap, sample.Evidence, valid, Before));

            var emptyPolicy = new Scenario(modulus, false, true);
            Expect("empty required evidence policy", "STOP",
                Evaluate(emptyPolicy, emptyPolicy.Evidence, Sign(signer, Payload(emptyPolicy.RequestHash)), Before));

            var denied = Expect("verified denial", "STOP", Evaluate(sample, sample.Evidence,
                Sign(signer, Payload(sample.RequestHash, "reviewer-1", "DENY")), Before));
            if (denied.ApprovalState != "DENIED")
                throw new InvalidOperationException("Verified denial not distinguished.");

            // A repeated review can reach the same decision, without obtaining any authority.
            Expect("same approval evaluated again", "REVIEW_SATISFIED",
                Evaluate(sample, sample.Evidence, valid, Before));
        }

        private static ReviewResult Evaluate(Scenario sample, Evidence[] evidence,
            ApprovalEnvelope approval, Context context)
        {
            return ReviewCore.Evaluate(sample.Policy, sample.Request, evidence, approval, context);
        }

        private static ReviewResult Expect(string name, string decision, ReviewResult result)
        {
            if (result == null || result.Decision != decision)
                throw new InvalidOperationException(name + ": expected " + decision + ", got " +
                    (result == null ? "<null>" : result.Decision) + ".");
            if (result.ExecutionAuthority != "NOT_GRANTED" || result.FreezeStatus != "FREEZE_BLOCKED")
                throw new InvalidOperationException(name + ": result exceeded the review boundary.");
            return result;
        }

        private static string Payload(string requestHash, string reviewer = "reviewer-1", string decision = "APPROVE")
        {
            return "MRC/0.1/APPROVAL\npurpose=review\nrequest_sha256=" + requestHash +
                "\ndecision=" + decision + "\nreviewer_id=" + reviewer +
                "\nreviewer_role=approver\nexpires_utc=" + Expiry + "\n";
        }

        private static SignedApproval Sign(RSA signer, string payload)
        {
            byte[] bytes = Bytes(payload);
            return new SignedApproval(bytes,
                signer.SignData(bytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1));
        }

        private static EvidenceReference[] References()
        {
            // Reverse role order to check ordinal canonical sorting.
            return new[]
            {
                new EvidenceReference("notes", "evidence-notes"),
                new EvidenceReference("content", "evidence-content")
            };
        }

        private static byte[] Bytes(string text) { return Encoding.UTF8.GetBytes(text); }

        private static string Hash(byte[] bytes)
        {
            using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
        }

        private sealed class Scenario
        {
            internal readonly TrustedPolicy Policy;
            internal readonly ReviewRequest Request;
            internal readonly Evidence[] Evidence;
            internal readonly string PolicyHash, RequestHash, ContentHash, NotesHash;

            internal Scenario(byte[] modulus, bool stop, bool empty)
            {
                byte[] content = Bytes("synthetic content"), notes = Bytes("synthetic notes");
                ContentHash = Hash(content);
                NotesHash = Hash(notes);

                // Build the expected bytes independently of the production encoder.
                string policyBytes = "MRC/0.1/POLICY\npolicy_id=policy-1\npolicy_version=1\npurpose=review\nstop=" +
                    (stop ? "1" : "0") + "\nrequired_count=" + (empty ? "0\n" : "2\n") +
                    (empty ? "" : "required.content=" + ContentHash + "\nrequired.notes=" + NotesHash + "\n") +
                    "reviewer_count=1\nreviewer.reviewer-1=approver:" + Hash(modulus) + "\n";
                PolicyHash = Hash(Bytes(policyBytes));
                Policy = new TrustedPolicy("policy-1", 1, "review", PolicyHash, stop,
                    empty ? new RequiredEvidence[0] : new[]
                    {
                        new RequiredEvidence("notes", NotesHash),
                        new RequiredEvidence("content", ContentHash)
                    },
                    new[] { new Reviewer("reviewer-1", "approver", modulus) });

                string requestBytes = "MRC/0.1/REQUEST\nrequest_id=request-1\nsubject_id=subject-1\npurpose=review\n" +
                    "policy_sha256=" + PolicyHash + "\nevidence_count=" + (empty ? "0\n" : "2\n") +
                    (empty ? "" : "evidence.content=evidence-content\nevidence.notes=evidence-notes\n");
                RequestHash = Hash(Bytes(requestBytes));
                Request = new ReviewRequest("request-1", "subject-1", "review", PolicyHash,
                    empty ? new EvidenceReference[0] : References());
                Evidence = empty ? new Evidence[0] : new[]
                {
                    new Evidence("evidence-notes", "notes", notes, NotesHash),
                    new Evidence("evidence-content", "content", content, ContentHash)
                };
            }
        }
    }
}
