using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Maestro.Review
{
    public sealed class RequiredEvidence
    {
        public readonly string Role, ExpectedSha256;
        public RequiredEvidence(string role, string expectedSha256)
        { Role = role; ExpectedSha256 = expectedSha256; }
    }

    public sealed class Reviewer
    {
        public readonly string Id, Role;
        internal readonly byte[] Modulus;
        public Reviewer(string id, string role, byte[] modulus)
        { Id = id; Role = role; Modulus = Snapshot.Copy(modulus); }
    }

    public sealed class TrustedPolicy
    {
        public readonly string Id, Purpose, PolicySha256;
        public readonly int Version;
        public readonly bool Stop;
        internal readonly RequiredEvidence[] Required;
        internal readonly Reviewer[] Reviewers;
        public TrustedPolicy(string id, int version, string purpose, string policySha256,
            bool stop, RequiredEvidence[] required, Reviewer[] reviewers)
        {
            Id = id; Version = version; Purpose = purpose; PolicySha256 = policySha256;
            Stop = stop; Required = Snapshot.Copy(required); Reviewers = Snapshot.Copy(reviewers);
        }
    }

    public sealed class EvidenceReference
    {
        public readonly string Role, Id;
        public EvidenceReference(string role, string id) { Role = role; Id = id; }
    }

    public sealed class ReviewRequest
    {
        public readonly string Id, SubjectId, Purpose, PolicySha256;
        internal readonly EvidenceReference[] References;
        public ReviewRequest(string id, string subjectId, string purpose, string policySha256,
            EvidenceReference[] references)
        {
            Id = id; SubjectId = subjectId; Purpose = purpose; PolicySha256 = policySha256;
            References = Snapshot.Copy(references);
        }
    }

    public sealed class Evidence
    {
        public readonly string Id, Role, ExpectedSha256;
        internal readonly byte[] Bytes;
        public Evidence(string id, string role, byte[] bytes, string expectedSha256)
        { Id = id; Role = role; Bytes = Snapshot.Copy(bytes); ExpectedSha256 = expectedSha256; }
    }

    public abstract class ApprovalEnvelope { internal ApprovalEnvelope() { } }

    public sealed class SignedApproval : ApprovalEnvelope
    {
        internal readonly byte[] Payload, Signature;
        public SignedApproval(byte[] payload, byte[] signature)
        { Payload = Snapshot.Copy(payload); Signature = Snapshot.Copy(signature); }
    }

    public sealed class MockApproval : ApprovalEnvelope { }

    public sealed class Context
    {
        public readonly DateTimeOffset? ReviewTimeUtc;
        public Context(DateTimeOffset? reviewTimeUtc) { ReviewTimeUtc = reviewTimeUtc; }
    }

    public sealed class VerifiedEvidence
    {
        public readonly string Role, Id, Sha256;
        internal VerifiedEvidence(string role, string id, string sha256)
        { Role = role; Id = id; Sha256 = sha256; }
    }

    public sealed class ReviewResult
    {
        public readonly string Decision, ApprovalState, RequestId, PolicyId;
        public readonly ReadOnlyCollection<string> Reasons, Unverified;
        public readonly ReadOnlyCollection<VerifiedEvidence> VerifiedEvidence;
        public string ExecutionAuthority { get { return "NOT_GRANTED"; } }
        public string FreezeStatus { get { return "FREEZE_BLOCKED"; } }

        internal ReviewResult(Findings findings, string requestId, string policyId)
        {
            Decision = findings.Stops.Count != 0 ? "STOP"
                : findings.Unknowns.Count != 0 ? "UNKNOWN" : "REVIEW_SATISFIED";
            ApprovalState = findings.ApprovalState;
            RequestId = requestId;
            PolicyId = policyId;
            Reasons = findings.Stops.AsReadOnly();
            Unverified = findings.Unknowns.AsReadOnly();
            VerifiedEvidence = findings.Verified.AsReadOnly();
        }
    }

    internal static class Snapshot
    {
        internal static T[] Copy<T>(T[] value) { return value == null ? null : (T[])value.Clone(); }
    }

    internal sealed class Findings
    {
        internal readonly List<string> Stops = new List<string>();
        internal readonly List<string> Unknowns = new List<string>();
        internal readonly List<VerifiedEvidence> Verified = new List<VerifiedEvidence>();
        internal string ApprovalState = "UNVERIFIED";
        internal void Stop(string reason) { if (!Stops.Contains(reason)) Stops.Add(reason); }
        internal void Unknown(string reason) { if (!Unknowns.Contains(reason)) Unknowns.Add(reason); }
    }

    public static class ReviewCore
    {
        private const int MaxEntries = 64;
        private static readonly StringComparer Ordinal = StringComparer.Ordinal;

        public static ReviewResult Evaluate(TrustedPolicy policy, ReviewRequest request,
            Evidence[] evidence, ApprovalEnvelope approval, Context context)
        {
            var f = new Findings();
            if (policy != null && policy.Stop) f.Stop("POLICY_STOP");

            bool policyShape = CheckPolicy(policy, f);
            bool requestShape = CheckRequest(request, f);
            bool policyPinned = false;
            string requestHash = null;
            if (policyShape)
            {
                string actual;
                if (!CanonicalApproval.TryPolicyHash(policy, out actual)) f.Unknown("HASH_PROVIDER_UNAVAILABLE");
                else if (!Ordinal.Equals(actual, policy.PolicySha256)) f.Stop("POLICY_SHA256_MISMATCH");
                else policyPinned = true;
            }
            if (requestShape && !CanonicalApproval.TryRequestHash(request, out requestHash))
                f.Unknown("HASH_PROVIDER_UNAVAILABLE");

            bool requestBound = false;
            var pins = new Dictionary<string, string>(Ordinal);
            var refs = new Dictionary<string, string>(Ordinal);
            if (policyShape)
                foreach (var item in policy.Required) pins.Add(item.Role, item.ExpectedSha256);
            if (requestShape)
                foreach (var item in request.References) refs.Add(item.Role, item.Id);
            if (policyShape && requestShape)
            {
                requestBound = Ordinal.Equals(request.Purpose, policy.Purpose)
                    && Ordinal.Equals(request.PolicySha256, policy.PolicySha256);
                if (!requestBound) f.Stop("REQUEST_POLICY_MISMATCH");
                foreach (var role in refs.Keys)
                    if (!pins.ContainsKey(role)) f.Stop("REQUEST_ROLE_UNEXPECTED");
                foreach (var role in pins.Keys)
                    if (!refs.ContainsKey(role)) f.Unknown("REQUEST_ROLE_MISSING");
            }

            if (evidence != null && evidence.Length > MaxEntries)
                f.Stop("EVIDENCE_LIMIT");
            else
                CheckEvidence(Snapshot.Copy(evidence), policyShape ? pins : null,
                    requestShape ? refs : null, policyPinned && requestBound, f);
            CheckApproval(approval, policyShape ? policy : null, requestShape ? request : null,
                requestHash, policyPinned && requestBound, context, f);

            if (f.ApprovalState != "HUMAN_APPROVED" && f.Stops.Count == 0 && f.Unknowns.Count == 0)
                f.Unknown("APPROVAL_NOT_ESTABLISHED");

            return new ReviewResult(f,
                request != null && CanonicalApproval.IsId(request.Id) ? request.Id : null,
                policy != null && CanonicalApproval.IsId(policy.Id) ? policy.Id : null);
        }

        private static bool CheckPolicy(TrustedPolicy policy, Findings f)
        {
            if (policy == null) { f.Unknown("POLICY_MISSING"); return false; }
            if (!CanonicalApproval.IsId(policy.Id) || !CanonicalApproval.IsId(policy.Purpose)
                || !CanonicalApproval.IsSha256(policy.PolicySha256) || policy.Version < 1
                || policy.Required == null || policy.Required.Length > MaxEntries
                || policy.Reviewers == null || policy.Reviewers.Length > MaxEntries)
            { f.Stop("POLICY_INVALID"); return false; }
            if (policy.Required.Length == 0) { f.Stop("POLICY_REQUIRED_EMPTY"); return false; }
            var roles = new HashSet<string>(Ordinal);
            var ids = new HashSet<string>(Ordinal);
            foreach (var item in policy.Required)
                if (item == null || !CanonicalApproval.IsId(item.Role)
                    || !CanonicalApproval.IsSha256(item.ExpectedSha256) || !roles.Add(item.Role))
                { f.Stop("POLICY_EVIDENCE_INVALID"); return false; }
            foreach (var reviewer in policy.Reviewers)
                if (reviewer == null || !CanonicalApproval.IsId(reviewer.Id)
                    || !CanonicalApproval.IsId(reviewer.Role) || !ids.Add(reviewer.Id)
                    || (reviewer.Modulus != null && !CanonicalApproval.IsModulus(reviewer.Modulus)))
                { f.Stop("POLICY_REVIEWER_INVALID"); return false; }
            return true;
        }

        private static bool CheckRequest(ReviewRequest request, Findings f)
        {
            if (request == null) { f.Unknown("REQUEST_MISSING"); return false; }
            if (!CanonicalApproval.IsId(request.Id) || !CanonicalApproval.IsId(request.SubjectId)
                || !CanonicalApproval.IsId(request.Purpose) || !CanonicalApproval.IsSha256(request.PolicySha256)
                || request.References == null || request.References.Length > MaxEntries)
            { f.Stop("REQUEST_INVALID"); return false; }
            var roles = new HashSet<string>(Ordinal);
            var ids = new HashSet<string>(Ordinal);
            foreach (var item in request.References)
                if (item == null || !CanonicalApproval.IsId(item.Role) || !CanonicalApproval.IsId(item.Id)
                    || !roles.Add(item.Role) || !ids.Add(item.Id))
                { f.Stop("REQUEST_EVIDENCE_INVALID"); return false; }
            return true;
        }

        private static void CheckEvidence(Evidence[] evidence, Dictionary<string, string> pins,
            Dictionary<string, string> refs, bool bound, Findings f)
        {
            if (evidence == null) { f.Unknown("EVIDENCE_MISSING"); return; }
            var roles = new HashSet<string>(Ordinal);
            var ids = new HashSet<string>(Ordinal);
            var covered = new HashSet<string>(Ordinal);
            var rolesById = new Dictionary<string, string>(Ordinal);
            if (refs != null)
                foreach (var pair in refs) rolesById.Add(pair.Value, pair.Key);
            var valid = new List<Evidence>();
            bool duplicate = false;
            foreach (var item in evidence)
            {
                if (item == null || !CanonicalApproval.IsId(item.Role) || !CanonicalApproval.IsId(item.Id)
                    || !CanonicalApproval.IsSha256(item.ExpectedSha256) || item.Bytes == null)
                { f.Stop("EVIDENCE_INVALID"); continue; }
                bool newRole = roles.Add(item.Role);
                bool newId = ids.Add(item.Id);
                if (!newRole || !newId) { f.Stop("EVIDENCE_DUPLICATE"); duplicate = true; }
                valid.Add(item);
            }
            foreach (var item in valid)
            {
                string expectedRole;
                if (rolesById.TryGetValue(item.Id, out expectedRole) && !Ordinal.Equals(expectedRole, item.Role))
                    f.Stop("EVIDENCE_ROLE_MISMATCH");
                string reference = null;
                bool mapped = refs != null && refs.TryGetValue(item.Role, out reference);
                bool sameId = mapped && Ordinal.Equals(reference, item.Id);
                if (mapped && !sameId) f.Stop("EVIDENCE_ID_MISMATCH");
                if (pins == null) continue;
                string expected;
                if (!pins.TryGetValue(item.Role, out expected)) { f.Stop("EVIDENCE_ROLE_UNEXPECTED"); continue; }
                covered.Add(item.Role);
                bool samePin = Ordinal.Equals(expected, item.ExpectedSha256);
                if (!samePin) f.Stop("EVIDENCE_PIN_MISMATCH");
                string observed;
                if (!CanonicalApproval.TryHash(item.Bytes, out observed)) f.Unknown("HASH_PROVIDER_UNAVAILABLE");
                else if (!Ordinal.Equals(expected, observed)) f.Stop("EVIDENCE_SHA256_MISMATCH");
                else if (bound && sameId && samePin && !duplicate)
                    f.Verified.Add(new VerifiedEvidence(item.Role, item.Id, observed));
            }
            if (pins != null)
                foreach (var role in pins.Keys)
                    if (!covered.Contains(role)) f.Unknown("REQUIRED_EVIDENCE_MISSING:" + role);
        }

        private static void CheckApproval(ApprovalEnvelope envelope, TrustedPolicy policy,
            ReviewRequest request, string requestHash, bool bound, Context context, Findings f)
        {
            if (envelope == null) { f.Unknown("APPROVAL_MISSING"); return; }
            if (envelope is MockApproval)
            { f.ApprovalState = "MOCK_APPROVED"; f.Stop("MOCK_APPROVAL"); return; }
            var signed = envelope as SignedApproval;
            ParsedApproval data;
            if (signed == null || !CanonicalApproval.TryParse(signed.Payload, out data)
                || !CanonicalApproval.IsSignature(signed.Signature))
            { f.Stop("APPROVAL_FORMAT_INVALID"); return; }

            bool purposeMatches = (policy == null || Ordinal.Equals(data.Purpose, policy.Purpose))
                && (request == null || Ordinal.Equals(data.Purpose, request.Purpose));
            bool hashMatches = requestHash != null && Ordinal.Equals(data.RequestSha256, requestHash);
            if (!purposeMatches) f.Stop("APPROVAL_PURPOSE_MISMATCH");
            if (requestHash != null && !hashMatches) f.Stop("APPROVAL_REQUEST_MISMATCH");

            bool hasTime = context != null && context.ReviewTimeUtc.HasValue
                && context.ReviewTimeUtc.Value.Offset == TimeSpan.Zero;
            bool fresh = hasTime && context.ReviewTimeUtc.Value < data.ExpiresUtc;
            if (!hasTime) f.Unknown("REVIEW_TIME_UNVERIFIED");
            else if (!fresh) f.Stop("APPROVAL_EXPIRED");

            Reviewer reviewer = null;
            if (policy != null)
                foreach (var item in policy.Reviewers)
                    if (Ordinal.Equals(item.Id, data.ReviewerId)) { reviewer = item; break; }
            bool roleMatches = reviewer != null && Ordinal.Equals(reviewer.Role, data.ReviewerRole);
            if (reviewer != null && !roleMatches) f.Stop("APPROVAL_ROLE_MISMATCH");
            if (reviewer == null || reviewer.Modulus == null)
            { f.Unknown("APPROVAL_KEY_UNAVAILABLE"); return; }

            SignatureStatus signature = CanonicalApproval.Verify(reviewer, signed.Payload, signed.Signature);
            if (signature == SignatureStatus.Invalid) f.Stop("APPROVAL_SIGNATURE_INVALID");
            if (signature == SignatureStatus.Unavailable) f.Unknown("SIGNATURE_PROVIDER_UNAVAILABLE");
            if (signature != SignatureStatus.Valid || !bound || !purposeMatches || !hashMatches
                || !roleMatches || !fresh) return;

            if (data.Decision == "DENY") { f.ApprovalState = "DENIED"; f.Stop("HUMAN_DENIED"); }
            else f.ApprovalState = "HUMAN_APPROVED";
        }
    }
}
