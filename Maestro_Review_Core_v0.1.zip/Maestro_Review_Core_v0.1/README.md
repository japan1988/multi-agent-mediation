# Maestro Review Core v0.1 公開候補

**REVIEW_SATISFIED は当該要求の審査条件の充足だけを示します。実行許可は付与されません。** 全結果の `ExecutionAuthority` は `NOT_GRANTED`、`FreezeStatus` は `FREEZE_BLOCKED` です。公開承認は別です。

## APIと責任境界

`Maestro.Review.ReviewCore.Evaluate(TrustedPolicy, ReviewRequest, Evidence[], ApprovalEnvelope, Context)` が唯一の評価入口です。入力はメモリ上の値です。呼出元は信頼済み方針と審査時刻を設定し、入力配列を渡している間の並行変更を避けます。ライブラリは配列とバイト列をコピーします。証拠の出所、現在時刻の真正性、審査後の差し替え防止は呼出元の責任です。APIは実行、監視、永続化、ファイル操作、通信、コールバックを持ちません。

`TrustedPolicy` の公開鍵は管理された信頼済み経路から受け取ります。署名は対応する秘密鍵の所持を示すため、実際に人間が承認したという帰属には鍵の管理と承認運用が必要です。承認署名の用途は審査に限定し、審査用途以外の承認データは受け付けません。消費記録を持たないため、同じ要求と署名の再提示には同じ審査結果が返り得ます。

## バイト表現 v0.1

共通仕様はBOMなしのUTF-8、ASCII文字のみ、ヘッダーを1行、その後に `name=value` を1行ずつ、区切りと末尾はLF 1バイトです。空行、余分な改行、空白、CR、エスケープ、余分なフィールドは許容しません。大文字と小文字を区別します。識別子は `[A-Za-z0-9][A-Za-z0-9._-]{0,63}`、SHA-256は小文字16進64桁です。件数は不変カルチャの10進表記で、符号・先頭ゼロなし、ゼロは `0` とします。

| ヘッダー | 後続行の順序 |
| --- | --- |
| `MRC/0.1/POLICY` | `policy_id`、`policy_version`、`purpose`、`stop`、`required_count`、その件数の `required.<role>=<sha256>`、`reviewer_count`、その件数の `reviewer.<id>=<role>:<modulus_sha256>`。 |
| `MRC/0.1/REQUEST` | `request_id`、`subject_id`、`purpose`、`policy_sha256`、`evidence_count`、その件数の `evidence.<role>=<evidence_id>`。 |
| `MRC/0.1/APPROVAL` | **6行固定**で `purpose`、`request_sha256`、`decision`、`reviewer_id`、`reviewer_role`、`expires_utc`。 |

- 方針と要求は型付きの値から生成します。可変行は役割または承認者IDの序数順に並べ、件数は実際の行数から求めます。各配列は最大64件です。方針の必須証拠は1件以上を必要とします。方針の必須役割・承認者ID、要求の証拠役割・証拠ID、提出証拠の役割・IDの重複は `STOP` です。nullの配列は構造不正です。ただし提出証拠全体がnullなら証拠未提出です。要求の対応や提出証拠に不足があれば `UNKNOWN` です。
- `policy_version` は正のInt32、`stop` は `0` または `1` です。方針の宣言ダイジェスト欄自体はハッシュ対象外です。公開鍵は符号なしビッグエンディアンのRSA法、最上位ビットが1で奇数、256・384・512バイト、公開指数は65537固定です。鍵指紋はRSA法の生バイト列のSHA-256です。鍵が未登録の承認者は法をnullとし、その行の指紋を `-` とします。空文字列を欠落の代わりに使用しません。
- 要求は `policy_sha256` により方針に結び付き、承認は `request_sha256` により要求・対象・方針に結び付きます。証拠の自己申告期待値は方針値と一致する必要があり、審査側は実測SHA-256を方針値と照合します。空のバイト列は証拠の欠落と区別します。
- 承認は固定順の6フィールドだけを持ちます。重複、未知フィールド、型違い、空値、順序違い、区切り違いを `STOP` とします。ペイロードは最大4096バイトです。`decision` は `APPROVE` または `DENY`、`expires_utc` は `YYYY-MM-DDTHH:mm:ssZ` の実在するUTC時刻です。署名はペイロードとは別の生バイト列で、RSA法と同じ長さ、符号なし整数として0より大きく法より小さい値です。
- ハッシュは `SHA256Cng`、署名は `RSACng.VerifyData` のRSA PKCS#1 v1.5 / SHA-256です。承認ペイロードの厳格な形式確認後、受け取ったバイト列を直接検証します。検証時の鍵は `TrustedPolicy` の承認者・役割に対応する公開鍵です。

## 判定と障害

| Decision | 条件 |
| --- | --- |
| `STOP` | 確定した拒否がある。方針停止、検証済みの拒否、ハッシュや束縛の不一致、既知の期限切れ、不正な形式や署名値、署名検証のfalse、模擬承認など。 |
| `UNKNOWN` | 確定した拒否はなく、証拠、時刻、承認、信頼鍵、暗号プロバイダーなどを確認できない。 |
| `REVIEW_SATISFIED` | 全必須証拠、方針、要求への束縛、有効な信頼済み承認が揃った。 |

優先順位は `STOP > UNKNOWN > REVIEW_SATISFIED` です。鍵や時刻の不足で別の確定STOPを消しません。期限との比較は呼出元から渡されたUTC時刻に対して行い、等しい場合も失効です。承認状態は `HUMAN_APPROVED`、`DENIED`、`MOCK_APPROVED`、`UNVERIFIED` です。無効と確認できる署名と、プロバイダーが検証を完了できない障害を区別します。予期しない例外が呼出元に返る場合に審査結果は成立しません。

## 配布内容と検証

C# 5互換、Windows .NET Framework 4.8系。配布ファイルの `Maestro.Review.dll` を .NET Framework 4.8 系のプロジェクトから参照できます。ソースからビルドする場合は `ReviewCore.cs` と `CanonicalApproval.cs` を同じライブラリにコンパイルします。`tests/ReviewCore.Tests.cs` は独立したテスト入口を持つソースです。公開契約に従って組み立てたサンプルのバイト列と、実行時にメモリ内で生成する合成鍵だけを使います。追加パッケージ、実鍵、実署名、個人情報は含めません。

### Windows 11 オフライン VM での動作確認

2026年11月15日、Windows 11 のオフライン VM で公開候補 ZIP の SHA-256 を照合し、展開した配布 DLL を参照して同梱テストをコンパイル・実行しました。テストは終了コード `0` を返し、検証スクリプトに `PASS: Maestro Review Core` と表示されました。同梱テストは署名検証、期限切れ、証拠の SHA-256 不一致などの判定を確認します。

- VM で照合した更新前 ZIP の SHA-256 は `A60294D175D4D663F40A9EFDA1BDD14BE80BB39B81D21CF8748EF4A013BB4CC6` です。
- テストが参照した DLL と本 ZIP 内の DLL の SHA-256 は、いずれも `D2B909C90CDD6DEE40BBD47DCA06FD67D7752FF8CE02B617F4A76F0E37EB9AE0` です。更新前 ZIP と本 ZIP を照合し、README 以外の配布ファイルは全てバイト単位で一致しました。

ZIP を展開した `Maestro_Review_Core_v0.1` フォルダーをカレントディレクトリとして、下記のコマンドで同じテストを再実行できます。

```powershell
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$dll = Join-Path $PWD 'Maestro.Review.dll'
$test = Join-Path $PWD 'tests\ReviewCore.Tests.cs'
$exe = Join-Path $PWD 'Maestro.Review.Tests.exe'

& $csc /nologo /langversion:5 /target:exe "/reference:$dll" "/out:$exe" $test
if ($LASTEXITCODE -ne 0) { throw "Test build failed ($LASTEXITCODE)" }
& $exe
if ($LASTEXITCODE -ne 0) { throw "Test failed ($LASTEXITCODE)" }
'PASS: Maestro Review Core'
```

この動作確認の範囲は配布 DLL を使った同梱テストです。

### 同梱ソースの再ビルド照合

同梱の `ReviewCore.cs` と `CanonicalApproval.cs` を Windows の .NET Framework 64 ビット版 C# コンパイラー（ファイルバージョン `14.8.10001.0`）で再ビルドしました。出力名は `Maestro.Review.dll`、オプションは `/nologo /langversion:5 /warnaserror /target:library` です。

配布 DLL と再ビルド DLL は共に 18,944 バイトでした。PE の COFF タイムスタンプ（4 バイト、位置 `0x0088`）と .NET のモジュール識別子 MVID（16 バイト、位置 `0x3DDC`）をそれぞれゼロにした比較用のコピーでは、全バイトが一致しました。比較用コピーの SHA-256 は両方とも `40F8F9FFEA2355E439F5A610FEC894F76EDF7425E9EDF328661791967282448B` です。ZIP には Windows 11 オフライン VM でテストした元の配布 DLL を収録しています。

`EXECUTION_AUTHORITY_NOT_GRANTED / PUBLICATION_NOT_APPROVED / FREEZE_BLOCKED`
