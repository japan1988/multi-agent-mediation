using System;
using System.Globalization;
using System.Security;
using System.Security.Cryptography;
using System.Text;

namespace Maestro.Review
{
    internal enum SignatureStatus { Valid, Invalid, Unavailable }

    internal sealed class ParsedApproval
    {
        internal readonly string Purpose, RequestSha256, Decision, ReviewerId, ReviewerRole;
        internal readonly DateTimeOffset ExpiresUtc;

        internal ParsedApproval(string purpose, string requestSha256, string decision,
            string reviewerId, string reviewerRole, DateTimeOffset expiresUtc)
        {
            Purpose = purpose;
            RequestSha256 = requestSha256;
            Decision = decision;
            ReviewerId = reviewerId;
            ReviewerRole = reviewerRole;
            ExpiresUtc = expiresUtc;
        }
    }

    internal static class CanonicalApproval
    {
        private const string Timestamp = "yyyy-MM-dd'T'HH:mm:ss'Z'";

        private static bool IsAsciiAlphanumeric(char c)
        {
            return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                (c >= '0' && c <= '9');
        }

        internal static bool IsId(string value)
        {
            if (String.IsNullOrEmpty(value) || value.Length > 64 ||
                !IsAsciiAlphanumeric(value[0]))
                return false;
            for (int i = 1; i < value.Length; i++)
            {
                char c = value[i];
                if (!IsAsciiAlphanumeric(c) && c != '.' && c != '_' && c != '-')
                    return false;
            }
            return true;
        }

        internal static bool IsSha256(string value)
        {
            if (value == null || value.Length != 64)
                return false;
            foreach (char c in value)
                if (!(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f'))
                    return false;
            return true;
        }

        private static bool IsRsaLength(int length)
        {
            return length == 256 || length == 384 || length == 512;
        }

        internal static bool IsModulus(byte[] value)
        {
            return value != null && IsRsaLength(value.Length) &&
                (value[0] & 128) != 0 && (value[value.Length - 1] & 1) != 0;
        }

        internal static bool IsSignature(byte[] value)
        {
            if (value == null || !IsRsaLength(value.Length))
                return false;
            foreach (byte octet in value)
                if (octet != 0)
                    return true;
            return false;
        }

        private static bool IsProviderFailure(Exception error)
        {
            return error is CryptographicException || error is NotSupportedException ||
                error is TypeLoadException || error is TypeInitializationException ||
                error is SecurityException || error is UnauthorizedAccessException;
        }

        internal static bool TryHash(byte[] bytes, out string lowercaseHex)
        {
            lowercaseHex = null;
            try
            {
                byte[] digest;
                using (var sha = new SHA256Cng())
                    digest = sha.ComputeHash(bytes);
                lowercaseHex = BitConverter.ToString(digest).Replace("-", "").ToLowerInvariant();
                return true;
            }
            catch (Exception error)
            {
                if (!IsProviderFailure(error))
                    throw;
                return false;
            }
        }

        private static void Field(StringBuilder text, string name, string value)
        {
            text.Append(name).Append('=').Append(value).Append('\n');
        }

        // The evaluator validates every field and rejects duplicate keys before hashing.
        internal static bool TryPolicyHash(TrustedPolicy policy, out string digest)
        {
            digest = null;
            var required = (RequiredEvidence[])policy.Required.Clone();
            var reviewers = (Reviewer[])policy.Reviewers.Clone();
            Array.Sort(required, (a, b) => String.CompareOrdinal(a.Role, b.Role));
            Array.Sort(reviewers, (a, b) => String.CompareOrdinal(a.Id, b.Id));

            var text = new StringBuilder("MRC/0.1/POLICY\n");
            Field(text, "policy_id", policy.Id);
            Field(text, "policy_version", policy.Version.ToString(CultureInfo.InvariantCulture));
            Field(text, "purpose", policy.Purpose);
            Field(text, "stop", policy.Stop ? "1" : "0");
            Field(text, "required_count", required.Length.ToString(CultureInfo.InvariantCulture));
            foreach (RequiredEvidence item in required)
                Field(text, "required." + item.Role, item.ExpectedSha256);

            Field(text, "reviewer_count", reviewers.Length.ToString(CultureInfo.InvariantCulture));
            foreach (Reviewer reviewer in reviewers)
            {
                string modulusHash = "-";
                if (reviewer.Modulus != null && !TryHash(reviewer.Modulus, out modulusHash))
                    return false;
                Field(text, "reviewer." + reviewer.Id, reviewer.Role + ":" + modulusHash);
            }
            return TryHash(Encoding.UTF8.GetBytes(text.ToString()), out digest);
        }

        internal static bool TryRequestHash(ReviewRequest request, out string digest)
        {
            var references = (EvidenceReference[])request.References.Clone();
            Array.Sort(references, (a, b) => String.CompareOrdinal(a.Role, b.Role));
            var text = new StringBuilder("MRC/0.1/REQUEST\n");
            Field(text, "request_id", request.Id);
            Field(text, "subject_id", request.SubjectId);
            Field(text, "purpose", request.Purpose);
            Field(text, "policy_sha256", request.PolicySha256);
            Field(text, "evidence_count", references.Length.ToString(CultureInfo.InvariantCulture));
            foreach (EvidenceReference item in references)
                Field(text, "evidence." + item.Role, item.Id);

            return TryHash(Encoding.UTF8.GetBytes(text.ToString()), out digest);
        }

        private static bool TryField(string line, string name, out string value)
        {
            value = null;
            string prefix = name + "=";
            if (!line.StartsWith(prefix, StringComparison.Ordinal))
                return false;
            value = line.Substring(prefix.Length);
            return true;
        }

        internal static bool TryParse(byte[] payload, out ParsedApproval parsed)
        {
            parsed = null;
            if (payload == null || payload.Length == 0 || payload.Length > 4096)
                return false;
            foreach (byte octet in payload)
                if (octet != 10 && (octet < 32 || octet > 126))
                    return false;

            string[] lines = Encoding.ASCII.GetString(payload).Split('\n');
            string purpose, requestHash, decision, reviewerId, role, expires;
            DateTimeOffset expiryUtc;
            if (lines.Length != 8 || lines[0] != "MRC/0.1/APPROVAL" || lines[7] != "" ||
                !TryField(lines[1], "purpose", out purpose) || !IsId(purpose) ||
                !TryField(lines[2], "request_sha256", out requestHash) || !IsSha256(requestHash) ||
                !TryField(lines[3], "decision", out decision) ||
                (decision != "APPROVE" && decision != "DENY") ||
                !TryField(lines[4], "reviewer_id", out reviewerId) || !IsId(reviewerId) ||
                !TryField(lines[5], "reviewer_role", out role) || !IsId(role) ||
                !TryField(lines[6], "expires_utc", out expires) ||
                !DateTimeOffset.TryParseExact(expires, Timestamp, CultureInfo.InvariantCulture,
                    DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out expiryUtc) ||
                expiryUtc.ToString(Timestamp, CultureInfo.InvariantCulture) != expires)
                return false;

            parsed = new ParsedApproval(purpose, requestHash, decision, reviewerId, role, expiryUtc);
            return true;
        }

        private static bool IsBelowModulus(byte[] signature, byte[] modulus)
        {
            for (int i = 0; i < signature.Length; i++)
                if (signature[i] != modulus[i])
                    return signature[i] < modulus[i];
            return false;
        }

        internal static SignatureStatus Verify(Reviewer reviewer, byte[] payload, byte[] signature)
        {
            if (payload == null || !IsSignature(signature))
                return SignatureStatus.Invalid;
            if (reviewer == null || reviewer.Modulus == null)
                return SignatureStatus.Unavailable;

            byte[] modulus = reviewer.Modulus;
            if (!IsModulus(modulus) || signature.Length != modulus.Length ||
                !IsBelowModulus(signature, modulus))
                return SignatureStatus.Invalid;

            try
            {
                using (var rsa = new RSACng())
                {
                    rsa.ImportParameters(new RSAParameters
                    {
                        Modulus = modulus,
                        Exponent = new byte[] { 1, 0, 1 }
                    });
                    return rsa.VerifyData(payload, signature, HashAlgorithmName.SHA256,
                        RSASignaturePadding.Pkcs1)
                        ? SignatureStatus.Valid : SignatureStatus.Invalid;
                }
            }
            catch (Exception error)
            {
                if (!IsProviderFailure(error))
                    throw;
                return SignatureStatus.Unavailable;
            }
        }
    }
}
